# AEC Drawing Extraction Report  
## Skyview Residences — Unit 03 Floor Plan

---

## 1. Project / Drawing Overview

### Project Information

| Item | Extracted Information |
|---|---|
| **Project name** | **Skyview Residences** |
| Project number | Not provided |
| Discipline | **Architectural** |
| Drawing type | **Residential floor plan** |
| Drawing title | **Unit 03 Floor Plan** |
| Sheet number | Not provided |
| Sheet title | Not provided |
| Page | **1** |
| Extraction status | **OK** |

The supplied data represents a single architectural residential floor plan for **Unit 03** at **Skyview Residences**.

### Level Information

| Level designation | Page |
|---|---:|
| **51-56** | 1 |

The drawing is associated with the level designation **51-56**. The JSON does not further clarify whether this designation represents a floor range, level range, or another project-specific reference.

### Drawing Scope

The extracted drawing information includes:

- Unit identification and residential program annotations
- Room and space names
- Selected room dimensions
- Overall, air-conditioned, and terrace areas
- General wall information
- Adjacency and access relationships
- A north arrow indication

No door, window, column, stair, elevation, material, finish, note, grid, or drawing-reference data was extracted.

---

## 2. Overall Element Count

The following counts reflect extracted records only. A count of zero means **0 extracted**, not that the physical drawing necessarily contains none.

| Element category | Extracted count |
|---|---:|
| Sheets | 1 |
| Levels | 1 |
| Grids | **0 extracted** |
| Rooms / spaces | 18 |
| Walls | 1 |
| Doors | **0 extracted** |
| Windows | **0 extracted** |
| Columns | **0 extracted** |
| Stairs | **0 extracted** |
| Dimension records | 3 |
| Elevations | **0 extracted** |
| Annotations / callouts | 4 |
| Drawing references / details | **0 extracted** |
| Materials / finishes | **0 extracted** |
| Construction / general notes | **0 extracted** |
| Space relationships | 7 |

The wall count represents one generalized wall record describing **exterior and interior partition walls throughout the unit floor plan**. It should not be interpreted as a count of individual wall segments.

---

## 3. Rooms / Spaces

A total of **18 rooms or spaces** were extracted from Page 1.

### Room and Space Schedule

| No. | Room / space | Extracted dimensions | Page |
|---:|---|---|---:|
| 1 | **Master Bedroom** | **11'-10" x 14'-0" (3.6 x 4.3 m)** | 1 |
| 2 | **Bedroom #2** | **10'-4" x 12'-0" (3.2 x 3.7 m)** | 1 |
| 3 | **Bedroom #3** | **10'-5" x 12'-0" (3.2 x 3.7 m)** | 1 |
| 4 | **Office/Family Room** | **9'-0" x 11'-0" (2.75 x 3.35 m)** | 1 |
| 5 | **Living/Dining Room** | **14'-0" x 36'-0"** | 1 |
| 6 | **Kitchen** | Not provided | 1 |
| 7 | **Master Bathroom** | Not provided | 1 |
| 8 | **Master W.I.C.** | Not provided | 1 |
| 9 | **Bathroom #2** | Not provided | 1 |
| 10 | **Bathroom #3** | Not provided | 1 |
| 11 | **Powder Room** | Not provided | 1 |
| 12 | **Foyer** | Not provided | 1 |
| 13 | **Vestibule** | Not provided | 1 |
| 14 | **Linen** | Not provided | 1 |
| 15 | **Closets** | Not provided | 1 |
| 16 | **Terrace** | Not provided as a room dimension; area provided separately | 1 |
| 17 | **Elevator #1** | Not provided | 1 |
| 18 | **Elevator #2** | Not provided | 1 |

### Bedroom Program

The drawing annotations identify the unit as having **3 BEDROOMS**. The extracted room list includes:

- Master Bedroom
- Bedroom #2
- Bedroom #3

The Master Bedroom is associated with the Master Bathroom and Master W.I.C. through extracted adjacency relationships. Bedroom #2 is associated with Bathroom #2, and Bedroom #3 is associated with Bathroom #3.

### Additional Living and Support Spaces

The unit includes the following extracted living, circulation, storage, and support spaces:

- **Living/Dining Room**
- **Kitchen**
- **Office/Family Room**
- **Foyer**
- **Vestibule**
- **Linen**
- **Closets**
- **Terrace**
- **Elevator #1**
- **Elevator #2**

### Bathroom and Toilet-Room Information

The extracted room list includes:

- Master Bathroom
- Bathroom #2
- Bathroom #3
- Powder Room

The drawing annotation states **“3 1/2 BATHROOMS + OFFICE.”** The supplied data does not provide a detailed fixture schedule or further breakdown explaining the relationship between the room names and the annotated bathroom count.

---

## 4. Dimensions

### Room Dimensions

The following room dimensions were explicitly extracted:

| Room | Imperial dimension | Metric dimension |
|---|---|---|
| **Master Bedroom** | **11'-10" x 14'-0"** | **3.6 x 4.3 m** |
| **Bedroom #2** | **10'-4" x 12'-0"** | **3.2 x 3.7 m** |
| **Bedroom #3** | **10'-5" x 12'-0"** | **3.2 x 3.7 m** |
| **Office/Family Room** | **9'-0" x 11'-0"** | **2.75 x 3.35 m** |
| **Living/Dining Room** | **14'-0" x 36'-0"** | Not provided |

No individual dimensions were extracted for the Kitchen, bathrooms, Foyer, Vestibule, Linen, Closets, Terrace, or elevators.

### Area Dimensions

| Area type | Extracted value | Page |
|---|---|---:|
| **Total area** | **1,885 sq.ft. (175 sq.m.)** | 1 |
| **A/C area** | **1,643 sq.ft. (153 sq.m.)** | 1 |
| **Terrace area** | **242 sq.ft. (22 sq.m.)** | 1 |

These values are reproduced as extracted. No additional area calculations have been performed.

### Dimensional Data Not Provided

The JSON does not include:

- Overall unit length or width
- Individual wall lengths
- Structural bay dimensions
- Door widths or heights
- Window widths or heights
- Ceiling heights
- Floor-to-floor heights
- Stair dimensions
- Elevator dimensions
- Dimension strings or witness-line references
- Dimension tolerances
- Dimension datum information

---

## 5. Wall Information

### Extracted Wall Record

| Wall type | Location | Page |
|---|---|---:|
| **Exterior and interior partition walls** | **Throughout unit floor plan** | 1 |

The extracted wall information identifies both exterior walls and interior partition walls as occurring throughout the unit floor plan.

### Wall Information Not Provided

The data does not identify:

- Wall thicknesses
- Wall types by location
- Structural versus nonstructural wall designation
- Rated wall assemblies
- Fire-resistance ratings
- Acoustic ratings
- Stud or masonry construction
- Sheathing or finish layers
- Shaft wall construction
- Demising wall construction
- Exterior wall material
- Interior partition material
- Wall height
- Wall base or trim conditions

The single wall record is a general description and is not an itemized wall schedule.

---

## 6. Doors / Windows / Openings

### Doors

**0 doors extracted.**

The supplied JSON does not contain door records, door tags, door numbers, door types, door swings, door dimensions, or hardware information. This extraction result does not establish that the physical drawing contains no doors.

### Windows

**0 windows extracted.**

No window records, window tags, window types, dimensions, glazing information, or sill/head heights were provided. This does not establish that the physical drawing contains no windows.

### Other Openings

No separate records were extracted for:

- Wall openings
- Pass-throughs
- Louvers
- Curtain wall systems
- Storefront systems
- Balcony or terrace openings
- Elevator openings
- Mechanical penetrations

The Terrace is identified as a space and has an extracted area, but no specific opening or access element is described in the supplied data.

---

## 7. Equipment / Fixtures / Building Systems

### Extracted Building-Related Spaces

The plan identifies the following spaces that may be associated with building systems or circulation infrastructure:

- **Elevator #1**
- **Elevator #2**
- **Kitchen**
- **Master Bathroom**
- **Bathroom #2**
- **Bathroom #3**
- **Powder Room**
- **Terrace**

These are room or space names only. No equipment or fixture data is provided for them.

### Equipment and Fixture Data

No individual equipment or fixture records were extracted. The JSON does not identify:

- Plumbing fixtures
- Kitchen appliances
- HVAC equipment
- Air-conditioning units
- Exhaust fans
- Electrical panels
- Distribution boards
- Fire alarm devices
- Sprinklers
- Smoke detectors
- Lighting fixtures
- Domestic water equipment
- Sanitary or storm drainage components
- Communications equipment
- Security systems
- Elevator equipment specifications

The extracted **A/C area** is an area classification and does not identify air-conditioning equipment or system design.

---

## 8. Annotations / Callouts

Four annotations or callouts were extracted from Page 1.

| Annotation / callout | Interpretation based on supplied data |
|---|---|
| **UNIT 03** | Identifies the residential unit |
| **3 BEDROOMS** | Identifies the bedroom count stated on the drawing |
| **3 1/2 BATHROOMS + OFFICE** | Provides the stated bathroom and office program description |
| **North arrow shown** | Indicates that a north arrow is shown on the drawing |

### Program Summary from Annotations

The drawing annotations describe the unit as:

- **Unit 03**
- **3 bedrooms**
- **3 1/2 bathrooms**
- **Office included**

The extracted room list separately identifies an **Office/Family Room** and four bathroom-related spaces: Master Bathroom, Bathroom #2, Bathroom #3, and Powder Room. The supplied data does not provide enough information to reconcile or further interpret the bathroom-count notation beyond recording both sources exactly.

---

## 9. Elevations

**0 elevations extracted.**

No elevation views, elevation markers, elevation tags, vertical datum references, or level-of-finish elevations were provided.

The level designation **51-56** is recorded in the JSON, but no elevation value or vertical coordinate is associated with it.

---

## 10. Materials / Finishes

**0 materials or finishes extracted.**

The supplied JSON contains no material or finish information for:

- Floors
- Walls
- Ceilings
- Countertops
- Cabinets
- Millwork
- Doors
- Windows
- Exterior cladding
- Terrace surfaces
- Bathroom finishes
- Kitchen finishes
- Hardware
- Paint or coating systems
- Waterproofing
- Sealants
- Flooring transitions

No finish schedule, material key, hatch legend, or finish callout was included in the extracted data.

---

## 11. Construction / General Notes

**0 construction or general notes extracted.**

The JSON does not include notes concerning:

- Construction requirements
- Demolition
- Dimensions and tolerances
- Coordination
- Field verification
- Accessibility
- Firestopping
- Waterproofing
- Acoustic requirements
- Mechanical, electrical, or plumbing coordination
- Finish installation
- Product specifications
- Contractor requirements
- Code compliance
- Inspection requirements
- Special conditions

No general notes block or keynotes were identified in the supplied extraction.

---

## 12. Space Relationships

Seven relationships were extracted from Page 1. These relationships describe adjacency or access and should not be interpreted as a complete circulation diagram unless additional drawing data is available.

### Adjacency Relationships

| From space | Relationship | To space | Page |
|---|---|---|---:|
| **Master Bedroom** | Adjacency | **Master Bathroom** | 1 |
| **Master Bedroom** | Adjacency | **Master W.I.C.** | 1 |
| **Living/Dining Room** | Adjacency | **Kitchen** | 1 |
| **Living/Dining Room** | Adjacency | **Terrace** | 1 |
| **Bedroom #2** | Adjacency | **Bathroom #2** | 1 |
| **Bedroom #3** | Adjacency | **Bathroom #3** | 1 |

### Access Relationship

| From | Access route | To | Page |
|---|---|---|---:|
| **Unit** | **via Vestibule** | **Elevator #1 and Elevator #2** | 1 |

### Relationship Summary

The extracted relationships indicate the following organization:

- The **Master Bedroom** is adjacent to both the **Master Bathroom** and **Master W.I.C.**
- The **Living/Dining Room** is adjacent to the **Kitchen**
- The **Living/Dining Room** is adjacent to the **Terrace**
- **Bedroom #2** is adjacent to **Bathroom #2**
- **Bedroom #3** is adjacent to **Bathroom #3**
- Access between the unit and **Elevator #1 and Elevator #2** is identified as occurring via the **Vestibule**

No additional relationship data was provided for the Foyer, Powder Room, Linen, Closets, Office/Family Room, or other spaces.

---

## 13. Drawing References / Details

**0 drawing references or details extracted.**

The JSON does not provide:

- Detail callouts
- Section references
- Elevation references
- Enlarged plan references
- Interior elevation references
- Sheet cross-references
- Specification references
- Keynote references
- Typical detail references
- Door or window schedule references
- Finish schedule references

The sheet number and sheet title are also not provided.

---

## 14. Important Measurements and Areas Summary

### Key Area Values

| Measurement category | Exact extracted value |
|---|---|
| **Total area** | **1,885 sq.ft. (175 sq.m.)** |
| **A/C area** | **1,643 sq.ft. (153 sq.m.)** |
| **Terrace area** | **242 sq.ft. (22 sq.m.)** |

### Key Room Dimensions

| Room / space | Exact extracted dimension |
|---|---|
| **Master Bedroom** | **11'-10" x 14'-0" (3.6 x 4.3 m)** |
| **Bedroom #2** | **10'-4" x 12'-0" (3.2 x 3.7 m)** |
| **Bedroom #3** | **10'-5" x 12'-0" (3.2 x 3.7 m)** |
| **Office/Family Room** | **9'-0" x 11'-0" (2.75 x 3.35 m)** |
| **Living/Dining Room** | **14'-0" x 36'-0"** |

### Program and Identification Values

| Item | Exact extracted information |
|---|---|
| Unit designation | **UNIT 03** |
| Bedroom annotation | **3 BEDROOMS** |
| Bathroom and office annotation | **3 1/2 BATHROOMS + OFFICE** |
| Level designation | **51-56** |
| North orientation | **North arrow shown** |

No dimensions have been inferred for spaces where values were not provided. No areas have been calculated from the room dimensions.

---

## 15. Compliance / Life Safety Information

No explicit compliance or life safety information was extracted.

The supplied JSON does not identify:

- Occupancy classification
- Occupant load
- Egress paths
- Exit access
- Exit doors
- Required exit width
- Travel distances
- Common path of travel
- Fire-resistance ratings
- Rated corridors
- Fire barriers
- Smoke barriers
- Fire alarm devices
- Sprinkler coverage
- Emergency lighting
- Accessibility clearances
- Accessible routes
- Accessible bathroom provisions
- Guardrails
- Handrails
- Stair compliance
- Elevator accessibility criteria
- Local code references
- Building code edition
- Life safety plans
- Fire department access information

The presence of elevators and the vestibule access relationship is recorded, but no compliance conclusion can be drawn from the supplied information.

---

## 16. Data Gaps / Extraction Limitations

The supplied extraction is limited to one architectural residential floor plan on Page 1. The following limitations apply:

### Identification and Sheet Data

- Project number is not provided.
- Sheet number is not provided.
- Sheet title is not provided.
- Only the drawing title **Unit 03 Floor Plan** is available.
- The meaning of the level designation **51-56** is not further defined.

### Geometric Data

- Only selected room dimensions are available.
- No overall unit dimensions are provided.
- No wall thicknesses or individual wall lengths are provided.
- No door, window, opening, ceiling, or vertical dimensions are provided.
- No dimensions are provided for most listed rooms and spaces.
- No geometric coordinates or drawing scale are included.

### Architectural Components

- Doors: **0 extracted**
- Windows: **0 extracted**
- Columns: **0 extracted**
- Stairs: **0 extracted**
- Grids: **0 extracted**
- Elevations: **0 extracted**

These zero counts indicate that no corresponding records were present in the supplied JSON. They do not prove that the physical drawing contains no such elements.

### Systems and Specifications

- No HVAC equipment or distribution information is provided.
- No plumbing fixtures or piping information is provided.
- No electrical fixtures, panels, or devices are provided.
- No fire protection or life safety devices are provided.
- No materials or finishes are provided.
- No construction or general notes are provided.

### Room and Program Interpretation

- The room list contains bathroom-related spaces that are not fully reconciled with the annotation **“3 1/2 BATHROOMS + OFFICE.”**
- The extracted information does not identify whether all listed spaces are enclosed, open, private, shared, or part of another area.
- The term **Master W.I.C.** is preserved as extracted; its expanded terminology is not provided.
- The extracted information does not describe the exact location or configuration of the Terrace beyond its area and adjacency to the Living/Dining Room.

### Reference and Coordination Data

- No section, detail, elevation, or sheet references are provided.
- No coordination references to structural, mechanical, electrical, plumbing, or civil drawings are provided.
- No revision information or issue date is provided.
- No scale or north-arrow angle/orientation data is provided beyond the statement that a north arrow is shown.

---

## 17. Final Human-Readable Summary

The supplied drawing data represents the **Skyview Residences — Unit 03 Floor Plan**, an **architectural residential floor plan** on **Page 1**. The plan is associated with level designation **51-56** and has an extraction status of **OK**.

Unit 03 is identified as a **3-bedroom** residence with the annotation **“3 1/2 BATHROOMS + OFFICE.”** The extracted spaces include a Master Bedroom, Bedroom #2, Bedroom #3, Office/Family Room, Living/Dining Room, Kitchen, multiple bathroom-related spaces, Foyer, Vestibule, Linen, Closets, Terrace, and two elevators.

The principal documented room dimensions are:

- **Master Bedroom:** 11'-10" x 14'-0" (3.6 x 4.3 m)
- **Bedroom #2:** 10'-4" x 12'-0" (3.2 x 3.7 m)
- **Bedroom #3:** 10'-5" x 12'-0" (3.2 x 3.7 m)
- **Office/Family Room:** 9'-0" x 11'-0" (2.75 x 3.35 m)
- **Living/Dining Room:** 14'-0" x 36'-0"

The documented area values are:

- **Total area:** 1,885 sq.ft. (175 sq.m.)
- **A/C area:** 1,643 sq.ft. (153 sq.m.)
- **Terrace area:** 242 sq.ft. (22 sq.m.)

The plan identifies exterior and interior partition walls throughout the unit. Extracted relationships show adjacency between the Master Bedroom and its Master Bathroom and Master W.I.C.; between the Living/Dining Room and the Kitchen; between the Living/Dining Room and Terrace; and between each secondary bedroom and its corresponding bathroom. Unit access to **Elevator #1 and Elevator #2** is identified as occurring via the **Vestibule**.

No individual doors, windows, columns, stairs, elevations, grids, materials, finishes, construction notes, life safety data, or drawing references were extracted. These omissions should be treated as unavailable in the supplied data and not as confirmation that such information is absent from the physical drawing.