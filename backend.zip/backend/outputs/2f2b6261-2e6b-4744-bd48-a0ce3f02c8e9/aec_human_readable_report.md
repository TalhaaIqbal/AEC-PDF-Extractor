# AEC Drawing Report

## 1. Project / Drawing Overview

### Project Information

| Item | Extracted Information |
|---|---|
| **Project name** | **RESTAURANT** |
| Project number | Not provided |
| Discipline | Architectural |
| Sheet count extracted | 1 |
| Available sheet | **A-1** |
| Sheet title | **FLOOR PLAN / EGRESS PLAN** |
| Drawing title | **FLOOR PLAN / EGRESS PLAN** |
| Drawing type | Floor plan and egress plan |
| Page | 1 |
| Extraction status | **OK** |

The supplied drawing information represents an architectural floor plan and egress plan for a restaurant project. The available sheet, **A-1**, includes room/space information, wall types, doors, dimensions, elevations, annotations, material references, construction notes, egress information, and drawing/detail references.

No levels or structural grid information were extracted.

---

## 2. Overall Element Count

The following counts represent extracted records from the supplied JSON. A count of zero means **0 extracted** and does not establish that the physical drawing contains no such elements.

| Element Category | Count Extracted | Notes |
|---|---:|---|
| Projects | 1 | Project identified as RESTAURANT |
| Sheets | 1 | Sheet A-1 |
| Levels | 0 extracted | No levels were provided |
| Grids | 0 extracted | No grids were provided |
| Rooms / spaces | 10 | Rooms numbered 101 through 110 |
| Walls | 5 | Existing and new wall types identified |
| Doors | 2 door categories | Swing doors and double doors |
| Windows | 0 extracted | No window records provided |
| Columns | 0 extracted | No column records provided |
| Stairs | 0 extracted | No stair records provided |
| Dimensions | 11 | Exact dimension strings preserved |
| Elevations | 2 | Includes N.G.V.D. and A.F.F. values |
| Annotations / callouts | 13 | Includes equipment, finishes, egress, and construction callouts |
| Drawing references / details | 5 | Details 1 through 4 and reference A-2 |
| Materials / finishes | 5 | Wall, framing, tile, and millwork materials |
| General / construction notes | 10 | Coordination, permitting, egress, and installation notes |
| Space relationships | 6 | Adjacency, egress, and flood protection relationships |

---

## 3. Rooms / Spaces

Ten rooms or spaces were extracted from Sheet A-1. Areas are reported only where explicitly provided. No areas have been calculated for spaces where the JSON does not provide an area.

| Room No. | Name | Area | Function | Page |
|---|---|---:|---|---:|
| **101** | **WAITING AREA** | **140 SQ FT** | Fixed seating waiting area | 1 |
| **102** | **WALK IN COOLER** | **80 SQ FT** | Walk-in cooler | 1 |
| **103** | **RESTROOM** | Not provided | Restroom | 1 |
| **104** | **RESTROOM** | Not provided | Restroom | 1 |
| **105** | **COUNTER** | Not provided | Service counter area | 1 |
| **106** | **DINING** | **100 SQ FT** | Dining area | 1 |
| **107** | **DINING** | **350 SQ FT** | Dining area | 1 |
| **108** | **PIZZA AREA** | **240 SQ FT** | Pizza preparation/cooking area | 1 |
| **109** | **PREP AREA** | **80 SQ FT** | Food preparation | 1 |
| **110** | **PREP AREA** | **46 SQ FT** | Food preparation | 1 |

### Room and Space Observations

- Room **101**, the **WAITING AREA**, is identified as a fixed seating waiting area and has an extracted area of **140 SQ FT**.
- Room **102** is a **WALK IN COOLER** with an extracted area of **80 SQ FT**.
- Rooms **103** and **104** are both identified as **RESTROOMS**. Their areas were not provided.
- Room **105** is identified as a **COUNTER** and functions as a service counter area. Its area was not provided.
- Rooms **106** and **107** are both identified as **DINING** spaces, with extracted areas of **100 SQ FT** and **350 SQ FT**, respectively.
- Room **108**, the **PIZZA AREA**, has an extracted area of **240 SQ FT** and is identified as a pizza preparation/cooking area.
- Rooms **109** and **110** are both identified as **PREP AREA** spaces, with extracted areas of **80 SQ FT** and **46 SQ FT**, respectively.
- The JSON does not provide occupancy values, occupant loads, room dimensions, or finish schedules for individual rooms.

---

## 4. Dimensions

The following dimension strings were extracted from Page 1. The JSON does not identify the precise location or geometric reference for each individual dimension unless otherwise noted.

| Extracted Dimension | Description / Context |
|---|---|
| **2'-4"** | Location not further specified in extracted data |
| **4'-5"** | Location not further specified in extracted data |
| **4'-0"** | Location not further specified in extracted data |
| **6'-3"** | Location not further specified in extracted data |
| **7'-4"** | Location not further specified in extracted data |
| **8'-8"** | Location not further specified in extracted data |
| **15'-6"** | Location not further specified in extracted data |
| **8'-0" LF bench** | Bench length annotation |
| **1'-5"** | Location not further specified in extracted data |
| **3'-0"** | Location not further specified in extracted data |
| **2'-10"** | Location not further specified in extracted data |

### Dimensioning Note

The drawing includes the following general dimensioning instruction:

> **All dimensions are made from face of frame to face of frame unless otherwise noted.**

The extracted data does not identify which walls, openings, rooms, or construction elements correspond to each dimension except for the explicit bench-related dimension **8'-0" LF bench**.

---

## 5. Wall Information

Five wall or partition descriptions were extracted from the drawing.

| Wall Type | Status / Construction | Page |
|---|---|---:|
| **Existing exterior wall** | Existing to remain | 1 |
| **Existing 2-hour fire-rated partition** | Existing | 1 |
| **New metal stud partition** | **3 5/8 in. 25 ga. metal studs** | 1 |
| **New 42 in. high low wall** | **3 5/8 in. 25 ga. metal studs** | 1 |
| **Interior partition wall** | **5/8 in. drywall** | 1 |

### Wall-Related Information

- An **existing exterior wall** is identified as existing to remain.
- An **existing 2-hour fire-rated partition** is identified.
- New partitions are described as using **3 5/8 in. 25 ga. metal studs**.
- A new **42 in. high low wall** is identified and is also associated with **3 5/8 in. 25 ga. metal studs**.
- An interior partition wall is identified with **5/8 in. drywall**.
- The extracted information does not provide wall locations, complete wall assembly build-ups, insulation information, finish sides, or fire-resistance details beyond the stated existing 2-hour fire-rated partition.

---

## 6. Doors / Windows / Openings

### Doors

Two door categories were extracted.

| Door Type | Locations / Description | Page |
|---|---|---:|
| **Swing doors** | Restrooms, service areas, dining areas, and exterior egress locations | 1 |
| **Double doors** | North exterior entrance and east dining-area exterior wall | 1 |

### Door and Egress Information

- Swing doors are indicated at:
  - Restrooms
  - Service areas
  - Dining areas
  - Exterior egress locations
- Double doors are indicated at:
  - The **north exterior entrance**
  - The **east dining-area exterior wall**
- The relationship data states that the plan indicates designated paths of egress and required exit swing direction.
- Individual door widths, door numbers, hardware, ratings, material, and handing were not provided in the extracted JSON.

### Windows

- **0 windows extracted.**
- This indicates that no window records were included in the supplied structured extraction. It does not establish that no windows are present on the physical drawing.

### Openings

The following opening-related annotation was extracted:

> **4' x 4' OPENING, 4' A.F.F.**

The opening is identified as being **4' x 4'** and located **4' A.F.F.** The exact wall or room location was not provided in the extracted data.

---

## 7. Equipment / Fixtures / Building Systems

The following equipment and building-system callouts were extracted from the drawing:

| Callout | Extracted Information |
|---|---|
| **OVEN** | Oven identified by annotation |
| **AHU** | AHU identified by annotation |
| **W.H.** | W.H. identified by annotation |
| **WALK IN COOLER** | Room 102 identified as a walk-in cooler |
| **BUILT-IN MILLWORK** | Built-in millwork identified; shop drawings required for approval |
| **FLOOD BARRIER** | Flood barrier callout identified |
| **TRASH ENCLOSURE** | Trash enclosure identified |
| **FENCE IN TRASH ENCLOSURE** | Fence within trash enclosure identified |
| **WALL MOUNTED FIRE EXTINGUISHER** | Wall-mounted fire extinguisher locations are denoted |

### Coordination Requirements

The construction notes require coordination of light fixtures with:

- Mechanical equipment
- Sprinkler equipment
- Structural members

The notes also require coordination of switching types and locations with the tenant before installation. Dimmers are to be provided as requested by the tenant and approved by the owner. Accent lighting locations are also to be coordinated with the tenant before installation.

The JSON does not provide equipment schedules, capacities, manufacturers, dimensions, utility connections, or detailed mechanical, electrical, plumbing, or fire protection layouts.

---

## 8. Annotations / Callouts

The following annotations and callouts were extracted from Page 1.

| Annotation / Callout | Category |
|---|---|
| **FLOOD BARRIER** | Flood protection |
| **TRASH ENCLOSURE** | Site/service area |
| **FENCE IN TRASH ENCLOSURE** | Site/service area |
| **OVEN** | Food-service equipment |
| **AHU** | Mechanical equipment |
| **W.H.** | Building-system/equipment callout |
| **BUILT-IN MILLWORK. PROVIDE SHOP DRAWINGS FOR APPROVAL.** | Millwork coordination |
| **ALIGN FACES OF FINISHES** | Finish coordination |
| **4' x 4' OPENING, 4' A.F.F.** | Opening |
| **PROVIDE CERAMIC TILE 4' A.F.F.** | Finish requirement |
| **8'-0" LF BENCH** | Fixed furnishing / bench |
| **DENOTES PATH OF EGRESS** | Life safety / egress |
| **DENOTES WALL MOUNTED FIRE EXTINGUISHER** | Fire protection |

### Annotation Interpretation

- **FLOOD BARRIER** callouts are associated with the building perimeter and exterior openings according to the relationship data.
- **TRASH ENCLOSURE** and **FENCE IN TRASH ENCLOSURE** identify an exterior or service-related enclosure condition.
- **OVEN**, **AHU**, and **W.H.** identify equipment or building-system elements, although the JSON does not define the full meaning of **W.H.**
- Built-in millwork requires shop drawings for approval.
- Finish faces are to be aligned where indicated.
- Ceramic tile is to be provided to **4 ft. A.F.F.**
- An **8'-0" LF BENCH** is identified.
- The plan includes graphic indications for paths of egress and wall-mounted fire extinguishers.

---

## 9. Elevations

Two elevation-related values were extracted.

| Elevation / Height | Location or Context | Page |
|---|---|---:|
| **+8.1' N.G.V.D.** | Waiting area / raised floor area | 1 |
| **4' A.F.F.** | Opening and finish-related annotations | 1 |

### Elevation Information

- The waiting area or raised floor area is associated with an elevation of **+8.1' N.G.V.D.**
- The value **4' A.F.F.** is associated with opening and finish-related annotations.
- The annotation **4' x 4' OPENING, 4' A.F.F.** identifies an opening at **4' A.F.F.**
- The annotation **PROVIDE CERAMIC TILE 4' A.F.F.** identifies a ceramic tile finish height of **4' A.F.F.**
- The extracted data does not identify a complete elevation datum scheme, benchmark location, vertical transitions, ceiling heights, or the exact limits of the raised floor area.

---

## 10. Materials / Finishes

The following materials and finish-related items were extracted.

| Material / Finish | Extracted Information |
|---|---|
| **5/8 in. drywall** | Identified material for an interior partition wall |
| **1-5/8 in. metal stud framing at 24 in. O/C** | Framing material and spacing |
| **3-5/8 in. 25 ga. metal stud partitions** | New partition construction |
| **Ceramic tile to 4 ft. A.F.F.** | Finish height requirement |
| **Built-in millwork** | Millwork item requiring shop drawings |

### Finish Coordination

The drawing includes the following finish-related direction:

- **ALIGN FACES OF FINISHES**
- **PROVIDE CERAMIC TILE 4' A.F.F.**

The JSON does not identify tile type, color, pattern, substrate, grout, waterproofing, flooring materials, ceiling finishes, paint colors, or complete finish assignments by room.

---

## 11. Construction / General Notes

The following construction and coordination notes were extracted from Page 1.

1. **All dimensions are made from face of frame to face of frame unless otherwise noted.**
2. **Contractor shall coordinate light fixtures with mechanical equipment, sprinkler equipment, and structural members.**
3. **Coordinate switching type and locations with tenant prior to installation; provide dimmers as requested by tenant and approved by owner.**
4. **Contractor shall coordinate accent lighting location with tenant prior to installation.**
5. **Contractor shall provide fire extinguishers as required by the plan and fire marshal.**
6. **Contractor shall provide required corridor and occupant-load signage.**
7. **Field verify and provide shop drawings for all millwork for owner and architect approval.**
8. **Contractor to verify all dimensions and contact architect with discrepancies.**
9. **Separated permit required for flood barriers and walk-in coolers.**
10. **Egress requirements shall comply with NFPA 101 requirements shown on the sheet.**

### Contractor Coordination Requirements

The extracted notes place responsibility on the contractor to:

- Coordinate lighting with mechanical, sprinkler, and structural elements.
- Coordinate switching locations and types with the tenant.
- Provide dimmers when requested by the tenant and approved by the owner.
- Coordinate accent lighting locations with the tenant.
- Provide fire extinguishers as required by the plan and fire marshal.
- Provide corridor and occupant-load signage.
- Field verify dimensions.
- Contact the architect regarding discrepancies.
- Provide millwork shop drawings for owner and architect approval.
- Obtain separated permits for flood barriers and walk-in coolers.

---

## 12. Space Relationships

Six spatial or functional relationships were extracted.

| Relationship Type | From | To | Description |
|---|---|---|---|
| Adjacency | **WAITING AREA 101** | **DINING 107** | Waiting area connects to the main dining area |
| Adjacency | **PIZZA AREA 108** | **PREP AREA 109** | Pizza area is adjacent to food preparation areas |
| Adjacency | **COUNTER 105** | **DINING 106** | Service counter is adjacent to dining area |
| Adjacency | **RESTROOM 103** | **RESTROOM 104** | Restrooms are located side by side |
| Egress | Interior occupied areas | Exterior exits | Plan indicates designated paths of egress and required exit swing direction |
| Flood protection | Building perimeter | Flood barriers | Flood barriers are indicated at multiple exterior openings/perimeter locations |

### Functional Organization

Based on the extracted relationships:

- The **WAITING AREA 101** connects to **DINING 107**.
- The **COUNTER 105** is adjacent to **DINING 106**, supporting a relationship between service and dining functions.
- The **PIZZA AREA 108** is adjacent to **PREP AREA 109**, supporting food preparation and cooking functions.
- **RESTROOM 103** and **RESTROOM 104** are positioned side by side.
- Interior occupied spaces are connected to exterior exits through designated egress paths.
- Flood barriers are associated with multiple exterior openings or perimeter locations.

The JSON does not provide a complete circulation diagram, distances between spaces, travel distances, corridor widths, or a full room-to-room adjacency matrix.

---

## 13. Drawing References / Details

Five drawing references were extracted from Page 1.

| Reference | Title | Page |
|---|---|---:|
| **Detail 1** | Floor plan / egress plan | 1 |
| **Detail 2** | Enlarged restroom plan | 1 |
| **Detail 3** | Interior elevation | 1 |
| **Detail 4** | Vault drop ceiling detail | 1 |
| **A-2** | Assembly | 1 |

### Reference Notes

- **Detail 1** is titled **Floor plan / egress plan**.
- **Detail 2** is titled **Enlarged restroom plan**.
- **Detail 3** is titled **Interior elevation**.
- **Detail 4** is titled **Vault drop ceiling detail**.
- Sheet **A-2** is referenced with the title **Assembly**.
- The supplied JSON does not include the contents of these details or the referenced sheet. Their presence is recorded, but their detailed requirements cannot be evaluated from the available data.

---

## 14. Important Measurements and Areas Summary

### Extracted Room Areas

| Room | Area |
|---|---:|
| **WAITING AREA 101** | **140 SQ FT** |
| **WALK IN COOLER 102** | **80 SQ FT** |
| **DINING 106** | **100 SQ FT** |
| **DINING 107** | **350 SQ FT** |
| **PIZZA AREA 108** | **240 SQ FT** |
| **PREP AREA 109** | **80 SQ FT** |
| **PREP AREA 110** | **46 SQ FT** |

Areas were not provided for:

- **RESTROOM 103**
- **RESTROOM 104**
- **COUNTER 105**

No total project area or total floor-plan area was provided. No additional areas have been calculated.

### Extracted Linear Dimensions

- **2'-4"**
- **4'-5"**
- **4'-0"**
- **6'-3"**
- **7'-4"**
- **8'-8"**
- **15'-6"**
- **8'-0" LF bench**
- **1'-5"**
- **3'-0"**
- **2'-10"**

### Extracted Heights and Elevations

- **+8.1' N.G.V.D.** — waiting area / raised floor area
- **4' A.F.F.** — opening and finish-related annotations
- **4' x 4' opening, 4' A.F.F.**
- Ceramic tile to **4 ft. A.F.F.**
- New low wall height: **42 in.**

### Construction Measurements

- New partition framing: **3 5/8 in. 25 ga. metal studs**
- Interior partition material: **5/8 in. drywall**
- Additional framing: **1-5/8 in. metal stud framing at 24 in. O/C**
- Bench length: **8'-0" LF**

---

## 15. Compliance / Life Safety Information

The drawing includes several life-safety and code-related indications.

### Egress

- The plan identifies paths of egress through the annotation:
  - **DENOTES PATH OF EGRESS**
- The relationship data states that interior occupied areas connect to exterior exits through designated paths of egress.
- Required exit swing direction is indicated in the plan relationship data.
- Swing doors are identified at exterior egress locations.
- Double doors are identified at the north exterior entrance and the east dining-area exterior wall.
- The construction notes state:
  > **Egress requirements shall comply with NFPA 101 requirements shown on the sheet.**

### Fire Protection

- An **existing 2-hour fire-rated partition** is identified.
- Wall-mounted fire extinguisher locations are denoted.
- The contractor is required to provide fire extinguishers as required by the plan and fire marshal.
- The contractor is required to provide corridor and occupant-load signage.
- Light fixtures are to be coordinated with sprinkler equipment and structural members.

### Flood Protection

- Flood barriers are identified at multiple exterior openings/perimeter locations.
- A separate permit is required for flood barriers.
- The drawing includes callouts for:
  - **FLOOD BARRIER**
  - **TRASH ENCLOSURE**
  - **FENCE IN TRASH ENCLOSURE**

### Compliance Limitations

The extracted JSON does not provide:

- Occupant-load calculations
- Egress widths
- Exit capacity calculations
- Travel distances
- Common path of travel
- Door hardware or panic hardware requirements
- Fire extinguisher type, rating, or spacing
- Complete fire-resistance-rated assemblies
- Accessibility clearances or fixture dimensions
- Plumbing fixture counts
- Detailed NFPA 101 calculations
- Authority having jurisdiction comments or approvals

The report therefore records the stated compliance requirements without independently determining code compliance.

---

## 16. Data Gaps / Extraction Limitations

The following information was not provided or was not extracted from the supplied JSON:

### Project and Sheet Information

- Project number
- Additional sheets beyond **A-1**
- Revision history
- Issue date
- Designer, architect, contractor, or owner information
- Drawing scale
- North arrow or orientation graphic
- Full title-block data

### Levels and Grids

- **0 levels extracted**
- **0 grids extracted**
- No floor-to-floor elevations
- No structural grid references
- No benchmark or control-point information beyond the extracted **+8.1' N.G.V.D.** value

### Rooms and Areas

- Areas for Rooms **103**, **104**, and **105**
- Total floor-plan area
- Occupant loads by room
- Room finish schedules
- Ceiling heights
- Complete room dimensions
- Furniture layouts beyond the extracted bench annotation and fixed seating description

### Walls and Assemblies

- Exact wall locations
- Complete wall-type identifiers
- Insulation
- Sheathing
- Fire-resistance assembly details
- Acoustic ratings
- Finish sides and finish schedules
- Partition head conditions
- Structural attachment details

### Doors, Windows, and Openings

- Door numbers
- Individual door widths and heights
- Door ratings
- Door hardware
- Door handing
- Door schedules
- Window records; **0 windows extracted**
- Window sizes and types
- Opening locations and detailed construction
- Accessibility clearances at doors and openings

### Equipment and Systems

- Equipment schedules
- Equipment dimensions
- Mechanical capacities
- AHU information
- Water-heater information associated with **W.H.**
- Plumbing connections
- Electrical loads
- Exhaust or ventilation requirements
- Sprinkler layout
- Fire alarm layout
- Lighting fixture schedule
- Utility requirements for the oven and walk-in cooler

### Materials and Finishes

- Flooring materials
- Ceiling materials
- Paint systems and colors
- Tile type, color, pattern, and grout
- Waterproofing details
- Millwork elevations and sections
- Countertop materials
- Finish transitions

### Compliance and Construction

- Occupant-load values
- Egress calculations
- Exit widths
- Travel distances
- Accessibility compliance information
- Required fire extinguisher locations and ratings
- Signage locations and sizes
- Permit documentation
- Flood-barrier design criteria
- Walk-in cooler permit documentation

### Referenced Details

The titles of Details 1 through 4 and Sheet A-2 were provided, but the actual detail drawings and sheet contents were not included. Requirements shown only in those referenced documents cannot be confirmed from the supplied JSON.

---

## 17. Final Human-Readable Summary

The supplied drawing package consists of one architectural sheet, **A-1 — FLOOR PLAN / EGRESS PLAN**, for the project identified as **RESTAURANT**. The sheet documents a restaurant floor plan with ten extracted spaces, including a waiting area, walk-in cooler, restrooms, counter, dining areas, pizza area, and preparation areas.

The identified spaces include:

- **WAITING AREA 101 — 140 SQ FT**
- **WALK IN COOLER 102 — 80 SQ FT**
- **RESTROOM 103**
- **RESTROOM 104**
- **COUNTER 105**
- **DINING 106 — 100 SQ FT**
- **DINING 107 — 350 SQ FT**
- **PIZZA AREA 108 — 240 SQ FT**
- **PREP AREA 109 — 80 SQ FT**
- **PREP AREA 110 — 46 SQ FT**

The plan identifies existing exterior walls, an existing 2-hour fire-rated partition, new metal stud partitions, a new **42 in. high low wall**, and interior partition walls using **5/8 in. drywall**. New partition construction includes **3 5/8 in. 25 ga. metal studs**, and the extracted material information also identifies **1-5/8 in. metal stud framing at 24 in. O/C**.

Door information includes swing doors at restrooms, service areas, dining areas, and exterior egress locations. Double doors are identified at the north exterior entrance and the east dining-area exterior wall. No window records were extracted.

The sheet includes egress indications, required exit swing direction, wall-mounted fire extinguisher callouts, and a note requiring compliance with **NFPA 101 requirements shown on the sheet**. The contractor is also directed to provide fire extinguishers as required by the plan and fire marshal, along with corridor and occupant-load signage.

Important extracted dimensions include **2'-4"**, **4'-5"**, **4'-0"**, **6'-3"**, **7'-4"**, **8'-8"**, **15'-6"**, **1'-5"**, **3'-0"**, and **2'-10"**. An **8'-0" LF bench** is also identified. Elevation-related information includes **+8.1' N.G.V.D.** at the waiting area or raised floor area and **4' A.F.F.** for opening and finish-related annotations.

The drawing also identifies an **OVEN**, **AHU**, **W.H.**, walk-in cooler, built-in millwork, flood barriers, a trash enclosure, and a fence within the trash enclosure. Built-in millwork requires field verification and shop drawings for owner and architect approval. Separate permits are required for flood barriers and walk-in coolers.

The extracted relationship information indicates that the waiting area connects to the main dining area, the pizza area is adjacent to a preparation area, the service counter is adjacent to a dining area, and the two restrooms are side by side. Designated egress paths connect interior occupied areas to exterior exits, while flood barriers are associated with multiple exterior openings or perimeter locations.

The available information is suitable for a high-level review of the extracted floor-plan content, room program, selected dimensions, wall types, egress indicators, and construction notes. It is not sufficient by itself to verify complete architectural, accessibility, structural, mechanical, electrical, plumbing, fire protection, or code compliance requirements.