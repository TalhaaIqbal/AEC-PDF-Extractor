# AEC Drawing Extraction Report

## 1. Project / Drawing Overview

### Project Identification

| Field | Extracted Information |
|---|---|
| **Project name** | **SW 1st Avenue Improvements** |
| **Project number** | **B-30833** |
| **Number of sheets** | **1 extracted** |
| **Sheet page** | Page **1** |
| **Sheet number** | **8** |
| **Sheet title** | **Roadway Plan** |
| **Drawing title** | **SW 1st Avenue Improvements** |
| **Discipline** | **Civil** |
| **Drawing type** | **Roadway plan** |
| **Page detection status** | **OK** |

The supplied drawing data represents a single civil roadway plan sheet for the **SW 1st Avenue Improvements** project. The plan includes roadway improvement information, milling and resurfacing limits, curb and gutter work, valley gutter work, existing features to remain, pedestrian ramp references, dimensions, elevations, and material symbols.

The drawing is associated with project number **B-30833** and is identified as **Sheet 8**.

---

## 2. Overall Element Count

The following counts reflect extracted elements in the supplied JSON. A count of zero means **0 extracted** from the provided drawing data; it does not establish that the corresponding elements are physically absent from the drawing or project.

| Element Category | Extracted Count |
|---|---:|
| Sheets | **1 extracted** |
| Levels | **0 extracted** |
| Grids | **0 extracted** |
| Rooms / spaces | **0 extracted** |
| Walls | **0 extracted** |
| Doors | **0 extracted** |
| Windows | **0 extracted** |
| Columns | **0 extracted** |
| Stairs | **0 extracted** |
| Dimensions | **6 extracted** |
| Elevations | **2 extracted** |
| Annotations / callouts | **12 extracted** |
| Drawing references | **3 extracted** |
| Materials / finish symbols | **3 extracted** |
| General notes | **2 extracted** |
| Space relationships | **5 extracted** |

The extracted content is primarily civil/site-related rather than architectural building-plan information. Consequently, conventional architectural categories such as rooms, doors, windows, walls, columns, and stairs contain no extracted entries.

---

## 3. Rooms / Spaces

### Extracted Rooms and Spaces

| Category | Result |
|---|---|
| Rooms | **0 extracted** |
| Named spaces | **0 extracted** |
| Room areas | **Not provided** |
| Space numbers | **Not provided** |
| Occupancy names | **Not provided** |

No rooms or enclosed building spaces were identified in the supplied extraction. The drawing is classified as a **civil roadway plan**, and the extracted data focuses on roadway improvements and associated site features.

The absence of room records does not indicate that no spatial areas exist in the physical project. It indicates only that no rooms or named building spaces were extracted from the supplied JSON.

---

## 4. Dimensions

Six dimensions were extracted from page 1. The values below are reproduced as provided.

| Dimension | Description | Page |
|---|---|---:|
| **50'** | Plan dimension | 1 |
| **20'** | Plan dimension | 1 |
| **30'** | Plan dimension | 1 |
| **20' R** | Curb return radius | 1 |
| **25'** | Dimension at SW 14th Terrace | 1 |
| **5'** | Dimension at SW 14th Terrace | 1 |

### Dimension Notes

- The **20' R** value is identified as a **curb return radius**.
- The **25'** and **5'** dimensions are specifically associated with **SW 14th Terrace**.
- The **50'**, **20'**, and **30'** values are identified only as plan dimensions in the supplied data.
- No dimension line locations, baseline references, offset descriptions, or dimension endpoint descriptions were provided for the general plan dimensions.
- No additional dimensions should be inferred from the extracted roadway relationships or annotations.

---

## 5. Wall Information

### Extracted Wall Data

| Wall Category | Result |
|---|---|
| Walls | **0 extracted** |
| Wall types | **Not provided** |
| Wall thicknesses | **Not provided** |
| Retaining walls | **0 extracted** |
| Building walls | **0 extracted** |

No wall elements were extracted. The supplied drawing data does include curb and gutter information, but curbs and gutters are reported separately as roadway annotations and should not be interpreted as building wall elements.

---

## 6. Doors / Windows / Openings

### Doors

- **0 doors extracted**
- Door numbers, types, widths, swings, hardware, and locations are **not provided**.

### Windows

- **0 windows extracted**
- Window numbers, types, sizes, glazing, and locations are **not provided**.

### Other Openings

No separately classified architectural or structural openings were extracted.

The plan does include references to **existing driveways**, but these are identified as existing roadway/site features rather than doors or building openings:

> **EXIST. DRIVEWAY (TO REMAIN)**

The supplied data also identifies a right-of-way line and roadway intersections, but no additional opening or access geometry was provided.

---

## 7. Equipment / Fixtures / Building Systems

### Extracted Equipment and Site Fixtures

| Item | Extracted Information | Status |
|---|---|---|
| Fire hydrant | Existing fire hydrant near the SW 15th Road and SW 1st Avenue intersection | To remain |
| Existing driveway | Existing driveway along SW 1st Avenue | To remain |
| Curb and gutter | Type “F” curb and gutter references | Construction and limits identified |
| Valley gutter | Existing and proposed valley gutter references | Removal, beginning, ending, and existing condition identified |
| Pedestrian ramps | Located at SW 1st Avenue intersections with SW 15th Road and SW 14th Terrace | Referenced in relationships |
| Detectable warning | Legend symbol | Material/symbol identified |

### Building Systems

The following building-system categories were not extracted:

- HVAC systems: **0 extracted**
- Plumbing systems: **0 extracted**
- Electrical systems: **0 extracted**
- Fire sprinkler systems: **0 extracted**
- Fire alarm systems: **0 extracted**
- Structural framing systems: **0 extracted**
- Domestic water systems: **Not provided**
- Sanitary sewer systems: **Not provided**
- Storm drainage systems: **Not provided**

The only explicitly identified utility-related fixture is an **existing fire hydrant**, which is noted as remaining. No utility sizes, pipe materials, elevations, connection details, or service information were supplied.

---

## 8. Annotations / Callouts

Twelve annotations were extracted from page 1.

### Construction Limits and Project Limits

| Annotation | Type | Page |
|---|---|---:|
| **BEGIN PROJECT: BEGIN MILLING & RESURFACING STA. 10+40.00 (MATCH EXIST.)** | Construction limit | 1 |
| **LIMITS OF MILLING & RESURFACING 49.00' RT (MATCH EXIST.)** | Construction limit | 1 |

These callouts identify the beginning of the project and the stated milling and resurfacing limits. The project beginning is identified at station **10+40.00**. The milling and resurfacing limit is identified as **49.00' RT**, with the annotation stating **MATCH EXIST.**

### Existing Features

| Annotation | Type | Page |
|---|---|---:|
| **EXIST. DRIVEWAY (TO REMAIN)** | Existing feature | 1 |
| **EXIST. FIRE HYDRANT (TO REMAIN)** | Existing feature | 1 |
| **EXIST. C&G (TO REMAIN)** | Existing feature | 1 |
| **EXIST. VALLEY GUTTER (TO REMAIN)** | Existing feature | 1 |

The existing features identified as remaining include a driveway, fire hydrant, curb and gutter, and valley gutter. The extraction does not provide exact coordinates or dimensions for these features beyond the associated relationship information and annotations.

### Demolition

| Annotation | Type | Page |
|---|---|---:|
| **REMOVE EXIST. VALLEY GUTTER** | Demolition | 1 |

The plan identifies removal of an existing valley gutter. The supplied data does not state the removal limits, removal quantity, disposal requirements, or replacement section details.

### Curb and Gutter

| Annotation | Type | Page |
|---|---|---:|
| **BEGIN TYPE "F" C&G** | Curb and gutter | 1 |
| **END TYPE "F" C&G** | Curb and gutter | 1 |
| **CONST. TYPE "F" C&G (TYP.)** | Curb and gutter | 1 |

The drawing identifies construction of **Type “F” curb and gutter**, including beginning and ending callouts and a typical construction notation. No curb height, gutter width, concrete strength, reinforcement, jointing, or section detail was included in the extracted JSON.

### Valley Gutter

| Annotation | Type | Page |
|---|---|---:|
| **BEGIN VALLEY GUTTER** | Valley gutter | 1 |
| **END VALLEY GUTTER** | Valley gutter | 1 |

The plan identifies the beginning and end of valley gutter work. The extraction does not specify valley gutter width, thickness, slope, material specification, or exact station limits.

---

## 9. Elevations

Two existing elevations were extracted from page 1.

| Elevation | Description | Page |
|---:|---|---:|
| **18.30** | Existing elevation at valley gutter | 1 |
| **18.39** | Existing elevation at end valley gutter | 1 |

### Elevation Interpretation

- **18.30** is identified as an existing elevation at the valley gutter.
- **18.39** is identified as an existing elevation at the end of the valley gutter.
- The elevation datum, units, vertical reference system, and benchmark information are **not provided**.
- No proposed elevations were extracted.
- No slopes, grades, drainage directions, or vertical alignment information were provided.

The values are preserved exactly as extracted and are not converted or recalculated.

---

## 10. Materials / Finishes

Three material or finish-related entries were extracted from the legend or symbols on page 1.

| Material / Symbol | Description | Page |
|---|---|---:|
| **Sod** | Legend indicates sod | 1 |
| **4" concrete** | Legend indicates 4-inch concrete | 1 |
| **Detectable warning** | Legend symbol | 1 |

### Material Information

- **Sod** is identified in the legend.
- **4" concrete** is identified in the legend as four-inch concrete.
- **Detectable warning** is identified as a legend symbol.
- No concrete mix design, compressive strength, reinforcement, subbase, curing, jointing, color, texture, or installation specification was provided.
- No sod species, soil preparation, watering, establishment, or limits were provided.
- No detectable-warning dimensions, product type, color, installation method, or placement limits were provided.

The extracted material information should not be expanded beyond the stated legend descriptions.

---

## 11. Construction / General Notes

Two notes were extracted from page 1.

### General Notes

1. **CR-X denotes pedestrian ramp (FDOT Index 304).**
2. **Plan includes milling and resurfacing improvements along SW 1st Avenue.**

### Construction Scope Identified in the Extraction

The drawing data indicates the following work or plan components:

- Milling and resurfacing improvements along **SW 1st Avenue**.
- A project beginning at **STA. 10+40.00**.
- Milling and resurfacing limits identified as **49.00' RT**.
- Existing conditions to be matched where noted by **MATCH EXIST.**
- Construction of **Type “F” curb and gutter**.
- Valley gutter beginning and ending references.
- Removal of an existing valley gutter.
- Existing driveway, fire hydrant, curb and gutter, and valley gutter identified as remaining.
- Pedestrian ramp references at the intersections of SW 1st Avenue with SW 15th Road and SW 14th Terrace.
- Use of the **CR-X** designation for pedestrian ramps, with reference to **FDOT Index 304**.

No construction sequencing, phasing, traffic-control plan, testing requirements, maintenance-of-traffic requirements, or contractor means and methods were provided in the JSON.

---

## 12. Space Relationships

Five relationships were extracted from page 1.

| Subject | Relationship | Object | Page |
|---|---|---|---:|
| **SW 1st Avenue** | Intersects | **SW 15th Road** | 1 |
| **SW 1st Avenue** | Intersects | **SW 14th Terrace** | 1 |
| **Pedestrian ramps** | Located at | **SW 1st Avenue intersections with SW 15th Road and SW 14th Terrace** | 1 |
| **Existing driveways** | Remain along | **SW 1st Avenue** | 1 |
| **Existing fire hydrant** | Remains near | **SW 15th Road and SW 1st Avenue intersection** | 1 |

### Relationship Summary

- **SW 1st Avenue** intersects both **SW 15th Road** and **SW 14th Terrace**.
- Pedestrian ramps are associated with the SW 1st Avenue intersections at those two cross streets.
- Existing driveways remain along SW 1st Avenue.
- An existing fire hydrant remains near the intersection of SW 15th Road and SW 1st Avenue.
- The extraction does not provide roadway widths, intersection angles, curb ramp orientations, driveway counts, or exact feature coordinates.

---

## 13. Drawing References / Details

Three drawing references were extracted from page 1.

| Reference | Type | Page |
|---|---|---:|
| **R/W LINE** | Right-of-way line | 1 |
| **MATCH LINE STA. 144+00.00** | Match line | 1 |
| **STA. 10+40.00** | Station | 1 |

### Reference Information

#### Right-of-Way Line

The plan references the **R/W LINE**, indicating a right-of-way line. No right-of-way width, acquisition limits, parcel information, or legal description was provided.

#### Match Line

The plan references **MATCH LINE STA. 144+00.00**. This indicates a drawing continuation or alignment reference at station **144+00.00**. No adjacent sheet number or continuation drawing reference was included in the supplied JSON.

#### Station Reference

The station **STA. 10+40.00** is identified both as a drawing reference and within the beginning-project annotation:

> **BEGIN PROJECT: BEGIN MILLING & RESURFACING STA. 10+40.00 (MATCH EXIST.)**

The extraction does not provide the station equation, baseline name, alignment definition, or stationing direction.

---

## 14. Important Measurements and Areas Summary

### Important Dimensions

| Item | Value | Description |
|---|---:|---|
| Plan dimension | **50'** | General plan dimension |
| Plan dimension | **20'** | General plan dimension |
| Plan dimension | **30'** | General plan dimension |
| Curb return radius | **20' R** | Curb return radius |
| SW 14th Terrace dimension | **25'** | Dimension at SW 14th Terrace |
| SW 14th Terrace dimension | **5'** | Dimension at SW 14th Terrace |
| Milling/resurfacing limit | **49.00' RT** | Construction annotation; match existing |
| Station at project beginning | **STA. 10+40.00** | Beginning milling and resurfacing |
| Match line station | **STA. 144+00.00** | Match-line reference |

### Important Elevations

| Item | Value | Description |
|---|---:|---|
| Existing valley gutter elevation | **18.30** | Existing elevation at valley gutter |
| Existing end valley gutter elevation | **18.39** | Existing elevation at end valley gutter |

### Areas

- Room areas: **0 extracted**
- Pavement areas: **Not provided**
- Milling area: **Not provided**
- Resurfacing area: **Not provided**
- Sod area: **Not provided**
- Concrete area: **Not provided**
- Right-of-way area: **Not provided**
- Parcel areas: **Not provided**

No areas should be calculated from the extracted dimensions. The supplied data does not provide sufficient information to determine pavement, resurfacing, sod, concrete, right-of-way, or other project areas.

---

## 15. Compliance / Life Safety Information

### Extracted Compliance-Related Information

The drawing includes the following accessibility- and pedestrian-related references:

- **CR-X denotes pedestrian ramp (FDOT Index 304).**
- **Detectable warning** is identified as a legend symbol.
- Pedestrian ramps are located at the SW 1st Avenue intersections with:
  - **SW 15th Road**
  - **SW 14th Terrace**

These entries indicate that pedestrian ramp and detectable-warning elements are included in the extracted plan information. However, the JSON does not provide enough information to verify compliance with any specific accessibility, roadway, building, or life-safety requirement.

### Life Safety and Code Information Not Provided

The following information was not extracted:

- Occupant loads
- Egress routes
- Exit access
- Fire-resistance ratings
- Fire alarm requirements
- Fire sprinkler requirements
- Emergency access requirements
- Fire department access dimensions
- Accessibility slopes
- Cross slopes
- Ramp widths
- Landing dimensions
- Detectable-warning dimensions
- Handrail or edge-protection requirements
- Applicable code editions
- Permit or approval status
- Inspection requirements

The reference to **FDOT Index 304** is reported as provided. No independent interpretation of that standard is made in this report.

---

## 16. Data Gaps / Extraction Limitations

The supplied JSON contains one roadway plan sheet and a focused set of extracted civil/site elements. The following limitations apply:

### Sheet and Drawing Coverage

- Only **one sheet** was supplied and extracted.
- The sheet is identified as **Sheet 8**.
- No other sheets, continuation sheets, plan/profile sheets, details, sections, or specifications were provided.
- The match line at **STA. 144+00.00** is present, but no adjacent sheet or continuation information was supplied.

### Geometric Information

- No complete roadway alignment was provided.
- No centerline, baseline, stationing direction, or horizontal control data was provided.
- No roadway widths, lane widths, shoulder widths, sidewalk widths, or curb offsets were extracted.
- No curb return geometry beyond the **20' R** value was provided.
- No exact coordinates were provided for intersections, driveways, fire hydrant, curb and gutter, valley gutter, ramps, or right-of-way line.
- No survey control, benchmarks, datum, or coordinate system was supplied.

### Vertical and Drainage Information

- Two existing elevations were extracted, but their datum and units are not provided.
- No proposed elevations were extracted.
- No grades, slopes, drainage flow directions, inlets, structures, pipes, or outfalls were identified.
- No hydraulic or stormwater calculations were included.

### Construction Quantities

- No quantities were supplied for milling, resurfacing, concrete, curb and gutter, valley gutter, sod, detectable warnings, or pedestrian ramps.
- No removal quantities were supplied for the existing valley gutter.
- No pay items, bid items, or cost information were provided.
- No construction duration or sequencing information was provided.

### Materials and Specifications

- Material entries are limited to **Sod**, **4" concrete**, and **Detectable warning**.
- No detailed specifications, performance requirements, product standards, installation requirements, or testing requirements were provided.
- No pavement section, asphalt mix, base course, subbase, or striping information was extracted.

### Existing Conditions

- Existing driveway, fire hydrant, curb and gutter, and valley gutter are identified.
- Their exact locations, dimensions, condition assessments, and survey coordinates are not provided.
- “To remain” annotations describe the stated plan intent but do not provide construction protection requirements.

### Architectural and Building Information

- No rooms, walls, doors, windows, columns, stairs, or building levels were extracted.
- No building floor areas, occupancy information, structural systems, or building services were provided.
- This limitation is consistent with the supplied sheet being a roadway plan, but it does not establish that no such information exists elsewhere in the project documents.

### Interpretation Limits

- General plan dimensions are not assigned to specific features unless the JSON provides that association.
- No missing dimensions, areas, or quantities have been estimated.
- No physical absence is inferred from an extracted count of zero.
- No compliance determination is made beyond reporting the extracted FDOT Index 304 and detectable-warning references.

---

## 17. Final Human-Readable Summary

The supplied drawing data represents **Sheet 8**, a civil **Roadway Plan** for the **SW 1st Avenue Improvements** project, project number **B-30833**.

The plan addresses milling and resurfacing improvements along **SW 1st Avenue**. The beginning of the project is identified at **STA. 10+40.00**, with the annotation stating:

> **BEGIN PROJECT: BEGIN MILLING & RESURFACING STA. 10+40.00 (MATCH EXIST.)**

The milling and resurfacing limits are identified as **49.00' RT**, also with a match-existing instruction.

The roadway plan identifies intersections of SW 1st Avenue with **SW 15th Road** and **SW 14th Terrace**. Pedestrian ramps are associated with these intersections, and the note states that **CR-X denotes pedestrian ramp (FDOT Index 304)**. A detectable-warning symbol is also included in the legend.

Existing features identified as remaining include an **existing driveway**, **existing fire hydrant**, **existing curb and gutter**, and **existing valley gutter**. The existing fire hydrant is located near the **SW 15th Road and SW 1st Avenue intersection**. The plan also identifies construction of **Type “F” curb and gutter**, including beginning, ending, and typical construction callouts. An existing valley gutter is identified for removal, while separate beginning and ending valley gutter references are also shown.

The extracted dimensions include **50'**, **20'**, **30'**, a **20' R** curb return radius, and dimensions of **25'** and **5'** at **SW 14th Terrace**. Two existing elevations are reported: **18.30** at the valley gutter and **18.39** at the end of the valley gutter. The drawing also references the **R/W LINE**, **MATCH LINE STA. 144+00.00**, and **STA. 10+40.00**.

Legend materials include **Sod**, **4" concrete**, and **Detectable warning**. No material quantities, pavement sections, construction details, areas, or cost information were extracted. No architectural building elements such as rooms, walls, doors, windows, columns, or stairs were extracted.

Overall, the available information documents a roadway improvement plan centered on milling and resurfacing, curb and gutter construction, valley gutter work, pedestrian ramp locations, and the preservation of selected existing site features. The report is limited to the information explicitly present in the supplied JSON; missing dimensions, quantities, areas, specifications, and compliance details remain **not provided**.