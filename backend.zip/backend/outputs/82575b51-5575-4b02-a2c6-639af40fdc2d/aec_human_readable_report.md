# AEC Drawing Extraction Report

## 1. Project / Drawing Overview

### Project Identification

| Item | Extracted Information |
|---|---|
| **Project name** | **SW 1st Avenue Improvements** |
| **Project number** | **B-30833** |
| **Discipline** | **Civil** |
| **Drawing type** | **Roadway plan** |
| **Drawing title** | **SW 1st AVENUE IMPROVEMENTS** |

### Sheet Information

| Page | Sheet Number | Sheet Title | Drawing Status |
|---:|---|---|---|
| 1 | **8** | **ROADWAY PLAN** | Detection status: **ok** |

This report is based on one extracted civil roadway-plan sheet. The supplied JSON identifies the drawing as a roadway improvement plan for SW 1st Avenue. No architectural floor plans, building levels, structural grids, or interior building elements were extracted.

---

## 2. Overall Element Count

The following counts reflect extracted elements in the supplied JSON. A count of zero means **0 extracted** and does not establish that the corresponding elements are physically absent from the drawing or project.

| Element Category | Extracted Count |
|---|---:|
| Sheets | **1 extracted** |
| Levels | **0 extracted** |
| Grids | **0 extracted** |
| Rooms / spaces | **0 extracted** |
| Walls | **0 extracted** |
| Doors | **0 extracted** |
| Windows | **0 extracted** |
| Columns | **0 extracted** |
| Stairs | **0 extracted** |
| Dimensions | **8 extracted** |
| Elevations | **2 extracted** |
| Annotations / callouts | **11 extracted** |
| Drawing references | **1 extracted** |
| Materials / finishes | **5 extracted** |
| General notes | **3 extracted** |
| Space relationships | **4 extracted** |

The extracted content is concentrated on roadway geometry, roadway limits, existing roadway features, curb and gutter work, pedestrian ramps, elevations, and construction annotations.

---

## 3. Rooms / Spaces

### Extracted Rooms and Spaces

No rooms or enclosed architectural spaces were extracted from the supplied drawing data.

| Item | Result |
|---|---|
| Rooms | **0 extracted** |
| Named interior spaces | **0 extracted** |
| Space numbers or room tags | **0 extracted** |
| Room areas | **0 extracted** |

The drawing is identified as a **civil roadway plan**, and the supplied JSON does not provide building-room information. No assumptions should be made regarding the presence or absence of rooms or spaces outside the extracted data.

---

## 4. Dimensions

Eight dimensions were extracted from page 1. The values below are reproduced as supplied, including the radius designation.

| No. | Dimension | Location | Page |
|---:|---|---|---:|
| 1 | **50'** | Upper roadway alignment | 1 |
| 2 | **20'** | Upper roadway alignment | 1 |
| 3 | **50'** | Upper roadway alignment | 1 |
| 4 | **30'** | Upper roadway alignment | 1 |
| 5 | **20' R** | Curb return near SW 15th Road | 1 |
| 6 | **25'** | SW 14th Terrace | 1 |
| 7 | **5'** | SW 14th Terrace | 1 |
| 8 | **25'** | SW 14th Terrace | 1 |

### Dimension Observations

- The upper roadway alignment includes extracted values of **50'**, **20'**, **50'**, and **30'**.
- A curb-return dimension of **20' R** is identified near **SW 15th Road**.
- Dimensions associated with **SW 14th Terrace** are **25'**, **5'**, and **25'**.
- The supplied data does not identify the endpoints, baseline references, station limits, or geometric elements associated with each individual dimension beyond the listed locations.
- No additional dimensions should be inferred from the extracted roadway relationships or annotations.

---

## 5. Wall Information

No walls were extracted from the supplied JSON.

| Wall Category | Extracted Result |
|---|---|
| Exterior walls | **0 extracted** |
| Interior walls | **0 extracted** |
| Retaining walls | **0 extracted** |
| Roadway edge walls or barriers | **0 extracted** |

The absence of extracted wall records does not confirm that no wall-like features appear elsewhere on the drawing. The supplied sheet is a roadway plan, and the provided extraction does not include wall information.

---

## 6. Doors / Windows / Openings

### Doors

- **0 doors extracted**

### Windows

- **0 windows extracted**

### Openings

- **0 openings extracted**

The supplied JSON does not provide building openings, door tags, window tags, driveway-apron opening dimensions, or other opening schedules. An existing driveway is identified as a roadway feature, but it is not extracted as a building door, window, or architectural opening.

---

## 7. Equipment / Fixtures / Building Systems

### Extracted Equipment and Utility-Related Features

No equipment, fixtures, or building systems were extracted as structured equipment records.

| Category | Extracted Result |
|---|---|
| Mechanical equipment | **0 extracted** |
| Electrical equipment | **0 extracted** |
| Plumbing fixtures | **0 extracted** |
| Fire protection equipment | **0 extracted** |
| Site lighting | **0 extracted** |
| Utility structures | **0 extracted** |
| Traffic-control equipment | **0 extracted** |

### Existing Fire Hydrant

An annotation identifies:

> **EXIST. FIRE HYDRANT (TO REMAIN)**

This is an existing site feature identified by callout. It is not represented in the JSON as an equipment object with a location, size, or service information.

### Roadway and Drainage Features

The extracted materials and annotations identify the following roadway-related systems and features:

- **Type F curb and gutter**
- **Valley gutter**
- **Existing curb and gutter**
- **Existing valley gutter**
- **Pedestrian ramps**
- **Detectable warning**
- **Sod**
- **4" concrete**

No capacities, slopes, utility sizes, pipe sizes, drainage calculations, or equipment specifications are provided.

---

## 8. Annotations / Callouts

Eleven annotations were extracted from page 1.

### Project and Construction Limits

| Annotation | Type | Page |
|---|---|---:|
| **BEGIN PROJECT: BEGIN MILLING & RESURFACING STA. 10+40.00 (MATCH EXIST.)** | Project limit | 1 |
| **LIMITS OF MILLING & RESURFACING 49.00' RT (MATCH EXIST.)** | Construction limit | 1 |
| **MATCH LINE STA. 14+00.00** | Match line | 1 |

These callouts establish an extracted project beginning at station **10+40.00** for milling and resurfacing and identify a milling and resurfacing limit of **49.00' RT**, with the note **“MATCH EXIST.”** A match line is identified at station **14+00.00**.

### Existing Features

| Annotation | Type | Page |
|---|---|---:|
| **EXIST. DRIVEWAY (TO REMAIN)** | Existing feature | 1 |
| **EXIST. FIRE HYDRANT (TO REMAIN)** | Existing feature | 1 |
| **EXIST. C&G (TO REMAIN)** | Existing feature | 1 |
| **EXIST. VALLEY GUTTER (TO REMAIN)** | Existing feature | 1 |

These annotations identify existing features intended to remain where indicated. The extracted data does not provide exact plan coordinates for each feature.

### Demolition and New Construction

| Annotation | Type | Page |
|---|---|---:|
| **REMOVE EXIST. VALLEY GUTTER** | Demolition | 1 |
| **BEGIN TYPE "F" C&G** | Curb and gutter | 1 |
| **END TYPE "F" C&G** | Curb and gutter | 1 |
| **CONST. TYPE "F" C&G (TYP.)** | Curb and gutter | 1 |

The drawing includes an instruction to remove existing valley gutter and callouts marking the beginning, end, and typical construction of **Type "F" curb and gutter**.

---

## 9. Elevations

Two elevations were extracted from page 1.

| No. | Elevation | Associated Feature | Page |
|---:|---|---|---:|
| 1 | **EL. 18.30** | Existing driveway | 1 |
| 2 | **EL. 18.39** | End valley gutter | 1 |

### Elevation Notes

- **EL. 18.30** is associated with the **existing driveway**.
- **EL. 18.39** is associated with the **end valley gutter**.
- The supplied JSON does not specify the vertical datum, units beyond the printed elevation notation, or whether the elevations are existing, proposed, or otherwise referenced beyond the feature descriptions.
- No additional elevation points, slopes, grades, or profiles were extracted.

---

## 10. Materials / Finishes

Five materials or roadway finish items were extracted from page 1.

| Material / Finish | Location or Application | Page |
|---|---|---:|
| **Sod** | Roadway improvements | 1 |
| **4" concrete** | Roadway improvements | 1 |
| **Detectable warning** | Pedestrian ramps | 1 |
| **Type F curb and gutter** | Roadway edges | 1 |
| **Valley gutter** | Driveway and roadway drainage areas | 1 |

### Material Interpretation Based on Extracted Data

- **Sod** is identified in connection with roadway improvements.
- **4" concrete** is identified in connection with roadway improvements. No area, reinforcement, strength, finish, or placement limits are provided.
- **Detectable warning** is identified at pedestrian ramps.
- **Type F curb and gutter** is identified at roadway edges and is also called out as typical construction.
- **Valley gutter** is identified in driveway and roadway drainage areas. Existing valley gutter is also identified as both remaining and subject to removal in different callouts.

No complete material schedule, product specifications, pavement section, aggregate requirements, reinforcement information, or finish schedule was extracted.

---

## 11. Construction / General Notes

Three general notes were extracted from page 1.

| Note | Page |
|---|---:|
| **CR-X denotes pedestrian ramp.** | 1 |
| **Existing driveways to remain.** | 1 |
| **Existing curb and gutter to remain where indicated.** | 1 |

### Construction-Related Extracted Information

The annotations and notes indicate the following work items and constraints:

- Milling and resurfacing begins at **STA. 10+40.00**, matching existing conditions.
- The milling and resurfacing limits include an extracted offset of **49.00' RT**, with the instruction **“MATCH EXIST.”**
- Existing driveways are to remain.
- Existing curb and gutter are to remain where indicated.
- An existing fire hydrant is identified to remain.
- Existing valley gutter is identified to remain in one location and is also identified for removal in another location.
- Type **"F"** curb and gutter is identified for construction, including beginning, ending, and typical construction callouts.
- A match line occurs at **STA. 14+00.00**.
- **CR-X** denotes a pedestrian ramp.
- Pedestrian ramp design is referenced to **FDOT Index 304**.

The supplied data does not include sequencing, means and methods, traffic-control requirements, testing requirements, inspection requirements, or contractor submittal requirements.

---

## 12. Space Relationships

The extracted relationships describe roadway intersections, pedestrian-ramp placement, and the beginning of resurfacing work.

| Feature A | Relationship | Feature B | Page |
|---|---|---|---:|
| **SW 1st Avenue** | Intersects | **SW 15th Road** | 1 |
| **SW 1st Avenue** | Intersects | **SW 14th Terrace** | 1 |
| **Pedestrian ramps** | Located at | **SW 1st Avenue intersections** | 1 |
| **Milling and resurfacing** | Begins at | **Station 10+40.00** | 1 |

### Relationship Summary

- **SW 1st Avenue** intersects **SW 15th Road**.
- **SW 1st Avenue** intersects **SW 14th Terrace**.
- Pedestrian ramps are located at the intersections along SW 1st Avenue.
- Milling and resurfacing begins at **Station 10+40.00**.
- The extracted dimension **20' R** is associated with a curb return near **SW 15th Road**.
- Additional dimensions of **25'**, **5'**, and **25'** are associated with **SW 14th Terrace**.

No complete intersection geometry, roadway widths, lane configuration, curb ramp orientation, or turning-movement information was extracted.

---

## 13. Drawing References / Details

One drawing reference was extracted.

| Reference | Description | Page |
|---|---|---:|
| **FDOT Index 304** | **Pedestrian ramp reference** | 1 |

The general note **“CR-X denotes pedestrian ramp.”** and the reference to **FDOT Index 304** establish a reference for pedestrian ramp work. No other standard details, sheet cross-references, specification sections, or detail callouts were extracted.

---

## 14. Important Measurements and Areas Summary

### Extracted Linear Dimensions

| Category | Values |
|---|---|
| Upper roadway alignment | **50'**, **20'**, **50'**, **30'** |
| Curb return near SW 15th Road | **20' R** |
| SW 14th Terrace | **25'**, **5'**, **25'** |

### Extracted Stations and Limits

| Item | Extracted Value |
|---|---|
| Beginning of milling and resurfacing | **STA. 10+40.00** |
| Match line | **STA. 14+00.00** |
| Milling and resurfacing limit | **49.00' RT** |
| Existing driveway elevation | **EL. 18.30** |
| End valley gutter elevation | **EL. 18.39** |

### Areas and Quantities

No room areas, pavement areas, concrete areas, sod areas, ramp areas, or construction quantities were extracted.

| Measurement Type | Result |
|---|---|
| Room areas | **Not provided** |
| Pavement areas | **Not provided** |
| Sod quantities | **Not provided** |
| Concrete quantities | **Not provided** |
| Curb and gutter quantities | **Not provided** |
| Valley gutter quantities | **Not provided** |
| Pedestrian ramp quantities | **Not provided** |
| Demolition quantities | **Not provided** |

No areas or quantities should be calculated from the listed dimensions, stations, annotations, or material descriptions.

---

## 15. Compliance / Life Safety Information

### Extracted Compliance-Related Information

The supplied data includes a pedestrian-ramp reference:

- **FDOT Index 304 — Pedestrian ramp reference**
- **CR-X denotes pedestrian ramp.**
- **Detectable warning** is identified at pedestrian ramps.
- Pedestrian ramps are located at **SW 1st Avenue intersections**.

### Life Safety Information

No building life-safety systems or code-compliance information were extracted.

| Category | Extracted Result |
|---|---|
| Occupancy classification | Not provided |
| Egress routes | Not provided |
| Fire-resistance ratings | Not provided |
| Exit signage | Not provided |
| Emergency lighting | Not provided |
| Fire alarm system | Not provided |
| Fire sprinkler system | Not provided |
| Accessible route dimensions | Not provided |
| Accessible slopes or cross slopes | Not provided |
| Curb-ramp slopes | Not provided |
| Handrails or guardrails | Not provided |

The presence of a fire hydrant annotation does not provide fire-flow, spacing, access, testing, or fire-protection compliance information. The supplied JSON contains no code analysis, permit review comments, accessibility calculations, or life-safety schedules.

---

## 16. Data Gaps / Extraction Limitations

The following information was not present in the supplied JSON or was not extracted from the drawing:

### Drawing and Spatial Data

- No additional sheets beyond page 1 were provided.
- No plan-scale information was provided.
- No north arrow, survey control, coordinate system, or benchmark information was provided.
- No roadway centerline coordinates or complete horizontal alignment data were provided.
- No station equations, curve data, bearings, or tangent lengths were provided.
- No complete intersection geometry was provided.
- No roadway widths, lane widths, shoulder widths, or pavement limits were provided.
- No cross sections or profiles were provided.

### Building and Architectural Data

- No levels were extracted.
- No grids were extracted.
- No rooms or enclosed spaces were extracted.
- No walls, doors, windows, columns, or stairs were extracted.
- No building area, occupancy, or architectural program information was provided.

### Civil and Construction Data

- No pavement section or pavement thickness schedule was provided.
- No roadway grades, cross slopes, drainage slopes, or longitudinal profiles were provided.
- No curb and gutter dimensions or section details were provided.
- No valley-gutter dimensions, grades, or drainage calculations were provided.
- No driveway geometry or driveway dimensions were provided.
- No pedestrian-ramp dimensions, slopes, landings, or detectable-warning dimensions were provided.
- No utility locations, utility sizes, invert elevations, or utility coordination information were provided.
- No construction quantities or bid-item quantities were provided.
- No demolition limits beyond the extracted valley-gutter callout were provided.
- No traffic-control or maintenance-of-traffic information was provided.
- No erosion-control or sediment-control information was provided.
- No specifications, testing requirements, or inspection requirements were provided.

### Existing and Proposed Conditions

- The JSON identifies several features as existing and/or remaining, but does not provide their exact plan locations.
- Existing valley gutter is identified both as **“TO REMAIN”** and for removal in separate annotations; the supplied data does not define the limits or locations that distinguish these conditions.
- The extraction does not identify which features are existing versus proposed beyond the wording of individual annotations.
- No complete construction phasing or sequencing information was extracted.

### Measurement and Reference Limitations

- The elevation datum is not provided.
- The units for stationing and elevations are not separately stated beyond the printed values.
- The dimension endpoints and extension-line references are not provided.
- No areas or quantities are available.
- No information was provided to confirm whether the extracted dimensions represent right-of-way widths, roadway widths, offsets, curb returns, or other geometric components except where the JSON explicitly identifies the location.

---

## 17. Final Human-Readable Summary

The supplied drawing is a civil **ROADWAY PLAN**, identified as sheet **8**, for the project **SW 1st Avenue Improvements**, project number **B-30833**. The drawing concerns improvements along **SW 1st Avenue**, including its intersections with **SW 15th Road** and **SW 14th Terrace**.

The extracted plan indicates that milling and resurfacing begins at **STA. 10+40.00**, with the project beginning at that station and matching existing conditions. A milling and resurfacing limit of **49.00' RT** is identified, and a match line occurs at **STA. 14+00.00**.

Existing roadway features called out in the extraction include an existing driveway, fire hydrant, curb and gutter, and valley gutter. Existing driveways are to remain, and existing curb and gutter are to remain where indicated. An existing valley gutter is identified for removal in one annotation, while another existing valley gutter is identified to remain. The plan also calls for construction of **Type "F" curb and gutter**, with annotations identifying its beginning, ending, and typical construction.

Pedestrian ramps are identified at SW 1st Avenue intersections. The note **“CR-X denotes pedestrian ramp.”** is provided, and pedestrian ramp work references **FDOT Index 304**. **Detectable warning** is identified as a ramp material or feature.

The extracted dimensions include **50'**, **20'**, **50'**, and **30'** along the upper roadway alignment; a **20' R** curb return near SW 15th Road; and **25'**, **5'**, and **25'** associated with SW 14th Terrace. Two elevations are identified: **EL. 18.30** at an existing driveway and **EL. 18.39** at the end of a valley gutter.

Materials and roadway elements identified in the extraction include **sod**, **4" concrete**, **detectable warning**, **Type F curb and gutter**, and **valley gutter**. No construction quantities, areas, complete roadway geometry, pavement sections, utility data, grades, accessibility dimensions, or life-safety information were provided.

All zero counts in this report represent **0 extracted** from the supplied JSON and should not be interpreted as confirmation that the corresponding elements are physically absent from the drawing or project.