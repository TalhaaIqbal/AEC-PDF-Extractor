# AEC Drawing Extraction Report

## 1. Project / Drawing Overview

### Project Information

| Field | Extracted Information |
|---|---|
| **Project name** | **SW 1st Avenue Improvements** |
| **Project number** | **B-30833** |
| **Discipline** | **Civil** |
| **Sheet number** | **3** |
| **Sheet title** | **TYPICAL SECTION** |
| **Drawing title** | **TYPICAL SECTION** |
| **Drawing type** | **Typical roadway sections** |
| **Page** | **1** |
| **Page detection status** | **OK** |

This report summarizes the extracted information from one civil drawing sheet for the **SW 1st Avenue Improvements** project. The sheet presents typical roadway sections, station ranges, roadway lane-width information, existing pavement and subgrade-related elements, curb and gutter types, and notes regarding existing improvements to remain.

The drawing includes the annotation **“TYPICAL SECTION (N.T.S.)”**, indicating that the typical section graphic is identified as **not to scale**. Exact values reported below are reproduced from the supplied extraction.

---

## 2. Overall Element Count

The following counts represent extracted elements in the supplied JSON. A count of zero means **0 extracted**; it does not establish that the corresponding elements are physically absent from the drawing or project.

| Element Category | Extracted Count |
|---|---:|
| Sheets | **1** |
| Levels | **0 extracted** |
| Grids | **0 extracted** |
| Rooms / spaces | **0 extracted** |
| Walls | **0 extracted** |
| Doors | **0 extracted** |
| Windows | **0 extracted** |
| Columns | **0 extracted** |
| Stairs | **0 extracted** |
| Dimensions / dimensional callouts | **9** |
| Elevations | **0 extracted** |
| Annotations | **8** |
| Drawing references / details | **0 extracted** |
| Materials | **5** |
| General notes | **1** |
| Relationship records | **2** |

### Sheet Coverage

Only one sheet was supplied:

- **Sheet 3 — TYPICAL SECTION**
- **Page 1**
- **Civil discipline**
- **Typical roadway sections**

No additional sheets, plans, profiles, details, or cross-referenced drawings were included in the extracted dataset.

---

## 3. Rooms / Spaces

### Extracted Room and Space Information

No rooms or enclosed architectural spaces were extracted from the drawing.

| Item | Result |
|---|---|
| Rooms | **0 extracted** |
| Named spaces | **0 extracted** |
| Room areas | **Not provided** |
| Room dimensions | **Not provided** |
| Occupancy space information | **Not provided** |

The supplied drawing is identified as a **civil typical roadway section** drawing rather than an architectural floor plan. The JSON contains no room names, space identifiers, room areas, or enclosed-space descriptions.

The roadway-related functional areas that are explicitly described through dimensional callouts include parking lanes, bike lanes, travel lanes, share lanes, and a buffer lane. These are reported in the **Dimensions** section and are not treated as rooms or enclosed spaces.

---

## 4. Dimensions

The drawing extraction contains nine dimensional records. These include four station ranges, one roadway reference-dimension callout, and four typical-section lane-width callouts.

### 4.1 Typical Section Station Ranges

| Description | Extracted Value | Page |
|---|---|---:|
| Typical section station range | **STA. 10+40.00 TO STA. 14+93.00** | 1 |
| Typical section station range | **STA. 14+93.00 TO STA. 17+83.00** | 1 |
| Typical section station range | **STA. 18+89.00 TO STA. 21+50.00** | 1 |
| Typical section station range | **STA. 21+50.00 TO STA. 25+00.00** | 1 |

These station ranges identify the roadway limits associated with the typical sections shown or referenced on the sheet. The extraction does not identify which specific graphic corresponds to each station range.

### 4.2 Roadway Reference Dimensions

| Description | Extracted Value | Page |
|---|---|---:|
| Roadway reference dimensions | **20 feet and 30 feet; 50 feet overall** | 1 |

The extraction provides the values **20 feet**, **30 feet**, and **50 feet overall**. The JSON does not specify the exact geometric features or endpoints associated with each of these values beyond the description **“Roadway reference dimensions.”**

### 4.3 Top-Left Typical Section Lane Widths

The top-left typical section includes the following extracted lane-width descriptions:

| Sequence / Element | Width |
|---|---:|
| Parking lane | **6.5 feet** |
| Bike lane | **5 feet** |
| Travel lane | **10 feet** |
| Share lane | **10 feet** |
| Parking lane | **5.5 feet** |

The complete extracted description is:

> **6.5-foot parking lane, 5-foot bike lane, 10-foot travel lane, 10-foot share lane, 5.5-foot parking lane**

The extraction does not provide a separate label for the overall section beyond the designation **“Top-left typical section lane widths.”**

### 4.4 Top-Right Typical Section Lane Widths

The top-right typical section includes the following extracted lane-width descriptions:

| Sequence / Element | Width |
|---|---:|
| Parking lane | **9 feet** |
| Share lane | **Variable 12 to 14 feet** |
| Share lane | **12 feet** |
| Buffer lane | **Variable 2 to 4 feet** |

The complete extracted description is:

> **9-foot parking lane, variable 12 to 14-foot share lane, 12-foot share lane, variable 2 to 4-foot buffer lane**

The values identified as variable are preserved as extracted. No single fixed width is substituted for either variable range.

### 4.5 Bottom-Left Typical Section Lane Widths

The bottom-left typical section includes:

| Sequence / Element | Width |
|---|---:|
| Share lane | **11 feet** |
| Travel lane | **11 feet** |
| Parking lane | **8.5 feet** |

The complete extracted description is:

> **11-foot share lane, 11-foot travel lane, 8.5-foot parking lane**

### 4.6 Bottom-Right Typical Section Lane Widths

The bottom-right typical section includes:

| Sequence / Element | Width |
|---|---:|
| Share lane | **11 feet** |
| Travel lane | **11 feet** |
| Parking lane | **7 feet** |

The complete extracted description is:

> **11-foot share lane, 11-foot travel lane, 7-foot parking lane**

### 4.7 Dimensional Limitations

The extraction does not provide:

- Overall cross-section widths for each typical section.
- Curb-to-curb dimensions for each section.
- Sidewalk widths.
- Pavement thicknesses beyond the stated milling and resurfacing depths.
- Cross slopes or superelevations.
- Vertical elevations.
- Station-to-section mapping for each graphic.
- Exact geometric endpoints for the **20 feet**, **30 feet**, and **50 feet overall** references.

No dimensions should be inferred from the listed lane widths.

---

## 5. Wall Information

No wall elements were extracted.

| Wall Information | Result |
|---|---|
| Wall count | **0 extracted** |
| Wall types | **Not provided** |
| Wall materials | **Not provided** |
| Wall dimensions | **Not provided** |
| Retaining walls | **Not provided** |
| Sound walls | **Not provided** |

The sheet is a roadway typical-section drawing, and the supplied JSON does not identify any wall objects or wall-specific annotations.

---

## 6. Doors / Windows / Openings

### Doors

- **0 doors extracted**
- Door types, sizes, hardware, and locations are **not provided**.

### Windows

- **0 windows extracted**
- Window types, sizes, glazing, and locations are **not provided**.

### Other Openings

No openings, penetrations, access panels, utility openings, or similar elements were extracted.

The absence of extracted doors, windows, and openings is consistent with the supplied sheet being identified as a civil roadway typical-section drawing. However, the extraction does not establish that no such items exist elsewhere in the project.

---

## 7. Equipment / Fixtures / Building Systems

No equipment, fixtures, or building systems were extracted from the supplied JSON.

| Category | Extracted Information |
|---|---|
| Mechanical equipment | **0 extracted** |
| Electrical equipment | **0 extracted** |
| Plumbing fixtures | **0 extracted** |
| Fire protection systems | **0 extracted** |
| Site furnishings | **0 extracted** |
| Utility structures | **0 extracted** |
| Traffic signal equipment | **0 extracted** |
| Street lighting | **0 extracted** |
| Drainage structures | **0 extracted** |
| Pavement marking systems | **0 extracted** |

The supplied data identifies roadway lane configurations and pavement-related treatments, but it does not include equipment schedules, utility systems, drainage structures, lighting, traffic control devices, or other building/site systems.

---

## 8. Annotations / Callouts

Eight annotations were extracted from page 1.

| Annotation / Callout | Page |
|---|---:|
| **M & B SURVEY** | 1 |
| **CROWN LINE** | 1 |
| **CL CONST.** | 1 |
| **EXIST. R/W LINE** | 1 |
| **EXIST. SIDEWALK (TO REMAIN)** | 1 |
| **EXIST. LIMERock BASE (TO REMAIN)** | 1 |
| **EXIST. SUB-BASE (TO REMAIN)** | 1 |
| **TYPICAL SECTION (N.T.S.)** | 1 |

### Annotation Interpretation Based on Extracted Text

- **M & B SURVEY** is present as an extracted survey-related annotation. The JSON does not define the abbreviation.
- **CROWN LINE** identifies a roadway crown-line annotation.
- **CL CONST.** identifies a construction centerline annotation.
- **EXIST. R/W LINE** identifies an existing right-of-way line.
- **EXIST. SIDEWALK (TO REMAIN)** indicates that the existing sidewalk is to remain where indicated.
- **EXIST. LIMERock BASE (TO REMAIN)** identifies existing limerock base to remain where indicated.
- **EXIST. SUB-BASE (TO REMAIN)** identifies existing sub-base to remain where indicated.
- **TYPICAL SECTION (N.T.S.)** identifies the graphic as a typical section and states that it is not to scale.

The extraction does not include coordinates, leader-line endpoints, or the exact graphic locations of these annotations.

---

## 9. Elevations

No elevation data was extracted.

| Elevation Category | Result |
|---|---|
| Spot elevations | **0 extracted** |
| Finished grades | **0 extracted** |
| Existing grades | **0 extracted** |
| Crown elevations | **0 extracted** |
| Curb elevations | **0 extracted** |
| Vertical profiles | **0 extracted** |
| Elevation benchmarks | **0 extracted** |

Although **CROWN LINE** is included as an annotation, no numerical crown elevation or cross-slope value is provided in the JSON.

---

## 10. Materials / Finishes

Five material records were extracted from page 1.

### 10.1 Existing Asphalt Pavement

| Field | Extracted Information |
|---|---|
| Material | **Existing asphalt pavement** |
| Treatment | **Mill existing asphalt pavement, 1-inch average depth** |
| Page | 1 |

The extracted treatment calls for milling the existing asphalt pavement to an **average depth of 1 inch**.

### 10.2 Type S-III Asphaltic Concrete

| Field | Extracted Information |
|---|---|
| Material | **Type S-III asphaltic concrete** |
| Treatment | **Resurface with 1-inch average depth** |
| Page | 1 |

The extracted treatment calls for resurfacing with Type S-III asphaltic concrete at an **average depth of 1 inch**.

### 10.3 Existing Limerock Base

| Field | Extracted Information |
|---|---|
| Material | **Existing limerock base** |
| Status | **To remain** |
| Page | 1 |

The existing limerock base is identified as **to remain**.

### 10.4 Existing Sub-Base

| Field | Extracted Information |
|---|---|
| Material | **Existing sub-base** |
| Status | **To remain** |
| Page | 1 |

The existing sub-base is identified as **to remain**.

### 10.5 Concrete Curb and Gutter

| Field | Extracted Information |
|---|---|
| Material | **Concrete curb and gutter** |
| Types | **Type F and Type D** |
| Page | 1 |

The extracted information identifies concrete curb and gutter of **Type F** and **Type D**. The JSON does not specify the station limits, locations, dimensions, or application criteria for each curb-and-gutter type.

### 10.6 Finish Information

No interior or architectural finish information was extracted. The material information is limited to roadway pavement, base, sub-base, and curb-and-gutter elements.

---

## 11. Construction / General Notes

One general note was extracted:

> **Existing sidewalk, limerock base, and sub-base to remain where indicated.**

### Construction-Related Information

The drawing extraction also identifies the following roadway work:

- Mill existing asphalt pavement to an **average depth of 1 inch**.
- Resurface with **Type S-III asphaltic concrete** at an **average depth of 1 inch**.
- Retain existing sidewalk, limerock base, and sub-base **where indicated**.
- Provide or identify concrete curb and gutter types **Type F** and **Type D**.

The word **“where indicated”** is preserved from the extracted note. The JSON does not identify all specific locations where the existing elements are to remain.

No additional information was extracted regarding:

- Construction sequencing.
- Traffic maintenance.
- Temporary works.
- Compaction requirements.
- Testing requirements.
- Asphalt mix specifications beyond the Type S-III designation.
- Subgrade preparation.
- Jointing.
- Restoration limits.
- Survey control procedures.
- Tolerances.
- Inspection requirements.
- Contractor responsibilities.

---

## 12. Space Relationships

The supplied relationship records describe roadway and existing-condition relationships rather than enclosed building spaces.

### Extracted Relationships

| Relationship | Applies To / Status | Page |
|---|---|---:|
| **Milling and resurfacing** | Applies to **existing roadway pavement** | 1 |
| **Existing curb and gutter, sidewalk, limerock base, and sub-base** | **Remain where indicated** | 1 |

### Relationship Summary

- The existing roadway pavement is associated with **milling and resurfacing** work.
- The existing curb and gutter, sidewalk, limerock base, and sub-base are identified as remaining **where indicated**.
- The drawing includes a **CROWN LINE**, **CL CONST.**, and **EXIST. R/W LINE** annotation, indicating roadway cross-section reference features.
- No room adjacencies, building circulation relationships, or interior space relationships were extracted.

---

## 13. Drawing References / Details

No drawing references or detail references were extracted.

| Reference Category | Result |
|---|---|
| Detail bubbles | **0 extracted** |
| Section references | **0 extracted** |
| Callouts to other sheets | **0 extracted** |
| Standard detail references | **0 extracted** |
| Specification references | **0 extracted** |
| External drawing references | **0 extracted** |

The sheet is identified as **Sheet 3**, but no other sheet numbers or referenced details are included in the supplied JSON.

The phrase **“TYPICAL SECTION (N.T.S.)”** is present as an annotation, but it is not represented in the JSON as a cross-sheet drawing reference.

---

## 14. Important Measurements and Areas Summary

### 14.1 Station Ranges

- **STA. 10+40.00 TO STA. 14+93.00**
- **STA. 14+93.00 TO STA. 17+83.00**
- **STA. 18+89.00 TO STA. 21+50.00**
- **STA. 21+50.00 TO STA. 25+00.00**

### 14.2 Roadway Reference Dimensions

- **20 feet**
- **30 feet**
- **50 feet overall**

The JSON does not identify the precise geometric meaning or location of each reference dimension.

### 14.3 Top-Left Typical Section

- **6.5-foot parking lane**
- **5-foot bike lane**
- **10-foot travel lane**
- **10-foot share lane**
- **5.5-foot parking lane**

### 14.4 Top-Right Typical Section

- **9-foot parking lane**
- **Variable 12 to 14-foot share lane**
- **12-foot share lane**
- **Variable 2 to 4-foot buffer lane**

### 14.5 Bottom-Left Typical Section

- **11-foot share lane**
- **11-foot travel lane**
- **8.5-foot parking lane**

### 14.6 Bottom-Right Typical Section

- **11-foot share lane**
- **11-foot travel lane**
- **7-foot parking lane**

### 14.7 Pavement Treatment Depths

- Mill existing asphalt pavement: **1-inch average depth**
- Type S-III asphaltic concrete resurfacing: **1-inch average depth**

### 14.8 Areas

No areas were extracted.

| Area Category | Result |
|---|---|
| Project area | **Not provided** |
| Roadway area | **Not provided** |
| Pavement area | **Not provided** |
| Sidewalk area | **Not provided** |
| Right-of-way area | **Not provided** |
| Room areas | **0 extracted / not applicable to supplied data** |

No areas have been calculated from the dimensional information. The listed lane widths and station ranges are not used to derive areas.

---

## 15. Compliance / Life Safety Information

No compliance or life-safety information was extracted from the supplied drawing JSON.

| Compliance / Life Safety Topic | Extracted Information |
|---|---|
| Building code references | **Not provided** |
| Accessibility references | **Not provided** |
| ADA dimensions | **Not provided** |
| Fire-resistance ratings | **Not provided** |
| Egress requirements | **Not provided** |
| Occupant loads | **Not provided** |
| Emergency access | **Not provided** |
| Traffic-control compliance | **Not provided** |
| Signing and pavement-marking standards | **Not provided** |
| Drainage compliance | **Not provided** |
| Environmental requirements | **Not provided** |
| Permitting information | **Not provided** |

The extracted data includes roadway lane types, parking lanes, a bike lane, share lanes, a buffer lane, right-of-way identification, and existing sidewalk information. However, no explicit compliance determination, standard reference, accessibility requirement, or life-safety requirement is included.

This report does not infer compliance from the extracted dimensions.

---

## 16. Data Gaps / Extraction Limitations

The following information was not present in the supplied JSON or was not extracted from the drawing:

### Drawing and Project Coverage

- Only **one sheet** was supplied.
- No additional plan, profile, detail, utility, drainage, signing, striping, or traffic-control sheets were included.
- No sheet index or drawing set context was provided.
- No revision history was provided.
- No issue date was provided.
- No designer, reviewer, or engineer-of-record information was provided.

### Geometry and Dimensions

- No section graphic coordinates were provided.
- No overall width was provided for each typical section.
- No exact location was provided for the **20 feet**, **30 feet**, or **50 feet overall** dimensions.
- No cross slopes, superelevations, grades, or vertical dimensions were provided.
- No curb heights, gutter widths, pavement cross slopes, or sidewalk widths were provided.
- No mapping was provided between station ranges and the four typical-section positions.
- No dimensions were provided for the Type F or Type D curb and gutter.

### Existing Conditions

- No surveyed elevations were provided.
- No survey control points were provided.
- No right-of-way widths were provided.
- No exact limits for existing sidewalk, limerock base, or sub-base retention were provided.
- The abbreviation **“M & B SURVEY”** was not defined in the JSON.

### Materials and Construction

- No asphalt specifications beyond **Type S-III asphaltic concrete** were provided.
- No material quantities were provided.
- No pavement area or resurfacing limits were provided.
- No construction sequence was provided.
- No testing, inspection, compaction, or quality-control requirements were provided.
- No information was provided regarding removal or replacement of curb, gutter, sidewalk, base, or sub-base.
- No treatment was provided for areas outside the extracted typical sections.

### Systems and Safety

- No drainage systems or drainage structures were extracted.
- No utilities were extracted.
- No signing, striping, signals, lighting, or traffic-control devices were extracted.
- No accessibility compliance information was extracted.
- No life-safety or code information was extracted.

### Interpretation Constraints

- The typical-section annotation states **N.T.S.**, so the graphic should not be measured graphically.
- The report preserves the extracted values exactly and does not calculate missing dimensions or areas.
- An extracted count of zero means **0 extracted**, not necessarily that the corresponding physical element is absent from the project.
- “To remain where indicated” is reported as written; the exact indicated limits are not included in the JSON.

---

## 17. Final Human-Readable Summary

The supplied drawing is **Sheet 3**, titled **TYPICAL SECTION**, for the civil project **SW 1st Avenue Improvements**, Project No. **B-30833**. The sheet presents typical roadway sections for several station ranges:

- **STA. 10+40.00 TO STA. 14+93.00**
- **STA. 14+93.00 TO STA. 17+83.00**
- **STA. 18+89.00 TO STA. 21+50.00**
- **STA. 21+50.00 TO STA. 25+00.00**

Four typical-section lane-width configurations are extracted. These include combinations of parking lanes, a bike lane, travel lanes, share lanes, and a variable-width buffer lane. The sheet also contains roadway reference dimensions of **20 feet**, **30 feet**, and **50 feet overall**, although the exact geometric associations for those values are not provided in the extraction.

The roadway material work includes milling existing asphalt pavement to an **average depth of 1 inch** and resurfacing with **Type S-III asphaltic concrete** at an **average depth of 1 inch**. Existing limerock base and existing sub-base are identified as **to remain**, and the general note states that the existing sidewalk, limerock base, and sub-base are to remain **where indicated**. Concrete curb and gutter types **Type F** and **Type D** are also identified.

The drawing includes roadway reference annotations for **M & B SURVEY**, **CROWN LINE**, **CL CONST.**, and **EXIST. R/W LINE**, along with labels identifying the existing sidewalk, limerock base, and sub-base as remaining. The typical section is explicitly labeled **“TYPICAL SECTION (N.T.S.)”**, meaning it is not to scale.

No rooms, walls, doors, windows, elevations, equipment, building systems, drawing references, quantities, areas, or compliance information were extracted. The supplied data is limited to one civil typical-section sheet and should be supplemented with the applicable plan, profile, detail, specification, survey, drainage, traffic-control, and project-notes documents before construction or final design decisions are made.