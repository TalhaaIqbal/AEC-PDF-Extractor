# AEC Drawing Report  
## Aria Reserve Miami - Skyview Residences — Unit 03

---

## 1. Project / Drawing Overview

### Project Identification

| Item | Extracted Information |
|---|---|
| **Project name** | **Aria Reserve Miami - Skyview Residences** |
| Project number | Not provided |
| Drawing title | **Unit 03** |
| Drawing type | **Residential unit floor plan** |
| Discipline | Not provided |
| Sheet number | Not provided |
| Sheet title | Not provided |
| Level designation | **Levels 51-56** |
| Drawing pages | Page **1** |
| Extraction status | Page 1 detection status: **ok** |

The supplied drawing data represents a residential unit floor plan identified as **Unit 03**. The unit is associated with **Levels 51-56** and is documented on a single extracted page, Page 1.

The drawing includes room names, selected room dimensions, overall area information, wall categories, annotations, and space relationships. The extracted data also identifies two elevators associated with access to the unit through a vestibule.

The drawing contains a general note stating:

> “All dimensions are approximate and all floor plans and development plans are subject to change.”

This note applies to the extracted dimensional information and indicates that the plan information is subject to revision.

---

## 2. Overall Element Count

The following counts represent elements extracted from the supplied JSON. They should not be interpreted as confirmed physical quantities where the extraction reports zero. In particular, a count of zero means **0 extracted**, not necessarily that the physical drawing or project contains none.

| Element Category | Extracted Count | Notes |
|---|---:|---|
| Sheets | 1 | One drawing page/sheet record |
| Pages | 1 | Page 1 |
| Levels | 1 | Levels 51-56 |
| Grids | 0 extracted | No grid information provided |
| Rooms / spaces | 15 | All associated with Page 1 |
| Wall categories | 2 | Exterior perimeter walls and interior partitions |
| Doors | 0 extracted | Door data not provided |
| Windows | 0 extracted | Window data not provided |
| Columns | 0 extracted | Column data not provided |
| Stairs | 0 extracted | Stair data not provided |
| Dimension records | 3 | Total area, A/C area, and terrace area |
| Elevations | 0 extracted | No elevation information provided |
| Annotations / callouts | 6 | Includes unit, bedroom/bathroom summary, elevators, and north arrow |
| Materials / finishes | 0 extracted | No material or finish information provided |
| General notes | 1 | Approximate dimensions and change notice |
| Space relationships | 7 | Six adjacency relationships and one access relationship |
| Drawing references / details | 0 extracted | No references listed |

---

## 3. Rooms / Spaces

A total of **15 rooms or spaces** are listed in the extracted data. All are associated with Page 1. Room numbers are provided only for Bedroom #2, Bedroom #3, Bathroom #2, and Bathroom #3.

### Room and Space Schedule

| Room / Space | Room Number | Extracted Dimensions | Page |
|---|---:|---|---:|
| **Master Bedroom** | Not provided | **11'-10" x 14'-0"**; **3.6 m x 4.3 m** | 1 |
| **Master Bathroom** | Not provided | Not provided | 1 |
| **Master W.I.C.** | Not provided | Not provided | 1 |
| **Bedroom #2** | **2** | **10'-4" x 12'-0"**; **3.2 m x 3.7 m** | 1 |
| **Bedroom #3** | **3** | **10'-5" x 12'-0"**; **3.2 m x 3.7 m** | 1 |
| **Bathroom #2** | **2** | Not provided | 1 |
| **Bathroom #3** | **3** | Not provided | 1 |
| **Office/Family Room** | Not provided | **9'-0" x 11'-0"**; **2.75 m x 3.35 m** | 1 |
| **Living/Dining Room** | Not provided | **14'-0" x 36'-0"**; **4.3 m x 11.0 m** | 1 |
| **Kitchen** | Not provided | Not provided | 1 |
| **Powder Room** | Not provided | Not provided | 1 |
| **Foyer** | Not provided | Not provided | 1 |
| **Vestibule** | Not provided | Not provided | 1 |
| **Linen** | Not provided | Not provided | 1 |
| **Terrace** | Not provided | Not provided | 1 |

### Bedroom and Bathroom Information

The extracted room list identifies:

- **Master Bedroom**
- **Bedroom #2**
- **Bedroom #3**
- **Master Bathroom**
- **Bathroom #2**
- **Bathroom #3**
- **Powder Room**

The annotations also state **“3 Bedrooms”** and **“3 1/2 Bathrooms + Office.”**

The JSON does not provide a detailed explanation of how the annotated bathroom count corresponds to the individually named bathroom-related spaces. Accordingly, the annotation and room names are reported as extracted without attempting to reconcile or reinterpret them.

### Other Residential Spaces

The unit includes the following additional spaces:

- **Office/Family Room**
- **Living/Dining Room**
- **Kitchen**
- **Foyer**
- **Vestibule**
- **Linen**
- **Terrace**

No dimensions were provided for the Master Bathroom, Master W.I.C., Bathroom #2, Bathroom #3, Kitchen, Powder Room, Foyer, Vestibule, Linen, or Terrace within the room records.

---

## 4. Dimensions

### Extracted Room Dimensions

The following room dimensions are explicitly provided in both imperial and metric units.

| Space | Imperial Dimension | Metric Dimension |
|---|---|---|
| Master Bedroom | **11'-10" x 14'-0"** | **3.6 m x 4.3 m** |
| Bedroom #2 | **10'-4" x 12'-0"** | **3.2 m x 3.7 m** |
| Bedroom #3 | **10'-5" x 12'-0"** | **3.2 m x 3.7 m** |
| Office/Family Room | **9'-0" x 11'-0"** | **2.75 m x 3.35 m** |
| Living/Dining Room | **14'-0" x 36'-0"** | **4.3 m x 11.0 m** |

### Area Dimensions

| Area Description | Extracted Value | Page |
|---|---|---:|
| **Total area** | **1,885 sq.ft.; 175 sq.m** | 1 |
| **A/C area** | **1,643 sq.ft.; 153 sq.m** | 1 |
| **Terrace area** | **242 sq.ft.; 22 sq.m** | 1 |

### Dimensional Qualifications

The drawing note states that:

> “All dimensions are approximate and all floor plans and development plans are subject to change.”

The extracted information does not identify whether the room dimensions are measured to finished face, wall centerline, or another reference condition. No additional dimension strings, construction dimensions, clearances, ceiling heights, door widths, window sizes, or structural dimensions were provided.

---

## 5. Wall Information

Two wall categories are identified in the extracted data.

| Wall Type | Location | Page |
|---|---|---:|
| **Exterior perimeter walls** | **Unit perimeter** | 1 |
| **Interior partitions** | **Throughout unit** | 1 |

### Exterior Perimeter Walls

The extracted data identifies exterior perimeter walls at the **unit perimeter**. No wall thicknesses, assembly descriptions, construction types, fire-resistance ratings, or material information were provided.

### Interior Partitions

Interior partitions are identified as occurring **throughout the unit**. The extraction does not provide partition thicknesses, stud sizes, shaft wall information, acoustic ratings, fire ratings, or finish layers.

### Wall Data Limitations

The supplied JSON does not include:

- Wall thicknesses
- Wall type codes
- Wall assembly descriptions
- Fire-resistance ratings
- Acoustic ratings
- Structural versus nonstructural classifications
- Rated corridor or shaft wall information
- Moisture-resistant wall requirements
- Finish types on either side of walls

---

## 6. Doors / Windows / Openings

### Doors

| Item | Extracted Information |
|---|---|
| Door count | **0 extracted** |
| Door types | Not provided |
| Door sizes | Not provided |
| Door swings | Not provided |
| Door hardware | Not provided |
| Door ratings | Not provided |
| Door tags | Not provided |

The extraction contains no door records. This means **0 doors were extracted from the supplied JSON**, not that the physical unit necessarily contains no doors.

### Windows

| Item | Extracted Information |
|---|---|
| Window count | **0 extracted** |
| Window types | Not provided |
| Window sizes | Not provided |
| Window tags | Not provided |
| Glazing information | Not provided |
| Window performance data | Not provided |

The extraction contains no window records. This means **0 windows were extracted from the supplied JSON**, not that the physical drawing necessarily contains no windows.

### Other Openings

No separate records for openings, storefront systems, sliding glass doors, exterior glazing, louvers, or other penetrations were provided.

The terrace is identified as a space and is related by adjacency to the Living/Dining Room, but the opening or door condition between these spaces is not described in the extracted data.

---

## 7. Equipment / Fixtures / Building Systems

### Extracted Equipment and Building System References

| Item | Extracted Information |
|---|---|
| Elevator #1 | Identified by annotation |
| Elevator #2 | Identified by annotation |
| Air-conditioning area | Area record: **1,643 sq.ft.; 153 sq.m** |
| Other equipment | Not provided |

The drawing annotations identify **Elevator #1** and **Elevator #2**. The relationship data states that the unit has access to **“Elevator #1 and Elevator #2 via Vestibule.”**

No elevator dimensions, shaft dimensions, machine room information, elevator type, accessibility information, or elevator specifications were provided.

### Fixtures

No fixture records were extracted. The room names indicate spaces that may conventionally contain plumbing or residential fixtures, including bathrooms, a powder room, kitchen, and laundry-related or storage-related areas; however, the supplied JSON does not identify any specific fixture locations or quantities. No fixtures should therefore be assumed from the extraction.

### Mechanical, Electrical, and Plumbing Systems

No specific mechanical, electrical, plumbing, fire protection, or ventilation system information was provided. The only system-related area designation is the extracted **A/C area** value of **1,643 sq.ft.; 153 sq.m**.

The following information is not provided:

- Air-conditioning equipment locations
- Supply or return air locations
- Exhaust systems
- Plumbing risers
- Electrical panels
- Receptacle locations
- Lighting fixtures
- Fire sprinkler locations
- Smoke or carbon monoxide detector locations
- Domestic water systems
- Sanitary or storm drainage information

---

## 8. Annotations / Callouts

The following annotations or callouts were extracted from Page 1.

| Annotation / Callout | Page |
|---|---:|
| **Unit 03** | 1 |
| **3 Bedrooms** | 1 |
| **3 1/2 Bathrooms + Office** | 1 |
| **Elevator #1** | 1 |
| **Elevator #2** | 1 |
| **North arrow shown** | 1 |

### Interpretation of Annotations

- **Unit 03** identifies the residential unit shown.
- **3 Bedrooms** summarizes the bedroom count indicated by the drawing.
- **3 1/2 Bathrooms + Office** provides a unit program summary as printed in the extracted data.
- **Elevator #1** and **Elevator #2** identify elevator-related access points or locations.
- **North arrow shown** confirms that orientation information is present on the drawing, although the actual directional orientation or graphical position of the north arrow is not included in the JSON.

---

## 9. Elevations

No elevation records were extracted.

| Elevation Information | Status |
|---|---|
| Elevation views | **0 extracted** |
| Elevation markers | Not provided |
| Exterior elevations | Not provided |
| Interior elevations | Not provided |
| Finish elevations | Not provided |
| Vertical dimensions | Not provided |
| Ceiling heights | Not provided |

The drawing is identified as a **residential unit floor plan**. The supplied JSON does not include building, interior, exterior, bathroom, kitchen, or wall elevations.

---

## 10. Materials / Finishes

No material or finish information was extracted.

| Category | Information Status |
|---|---|
| Flooring | Not provided |
| Wall finishes | Not provided |
| Ceiling finishes | Not provided |
| Countertops | Not provided |
| Cabinetry | Not provided |
| Bathroom finishes | Not provided |
| Kitchen finishes | Not provided |
| Terrace finishes | Not provided |
| Exterior wall materials | Not provided |
| Glazing materials | Not provided |
| Paint colors | Not provided |
| Finish schedule references | Not provided |

Although the drawing identifies spaces such as the Kitchen, bathrooms, Living/Dining Room, and Terrace, no finish selections or material descriptions are included in the supplied JSON.

---

## 11. Construction / General Notes

One general note was extracted from Page 1:

> **“All dimensions are approximate and all floor plans and development plans are subject to change.”**

### Significance of the General Note

This note establishes the following limitations for use of the extracted information:

- The listed dimensions are identified as approximate.
- The floor plan is subject to change.
- Development plans are subject to change.
- The extracted data should not be treated as a final construction document without confirmation from the applicable issued drawing set.
- Missing information should not be interpreted as a physical absence from the unit or drawing.

No additional construction notes were provided regarding:

- Construction sequencing
- Tolerances
- Code requirements
- Coordination requirements
- Waterproofing
- Acoustic requirements
- Structural requirements
- Accessibility
- Demolition
- Existing conditions
- Installation requirements
- Product standards
- Submittals
- Inspection requirements

---

## 12. Space Relationships

Seven space or access relationships were extracted from Page 1.

### Adjacency Relationships

| Relationship Type | From | To | Page |
|---|---|---|---:|
| Adjacency | **Master Bedroom** | **Master Bathroom** | 1 |
| Adjacency | **Master Bedroom** | **Master W.I.C.** | 1 |
| Adjacency | **Kitchen** | **Living/Dining Room** | 1 |
| Adjacency | **Living/Dining Room** | **Terrace** | 1 |
| Adjacency | **Bedroom #2** | **Bathroom #2** | 1 |
| Adjacency | **Bedroom #3** | **Bathroom #3** | 1 |

### Access Relationship

| Relationship Type | From | To | Page |
|---|---|---|---:|
| Access | **Unit** | **Elevator #1 and Elevator #2 via Vestibule** | 1 |

### Relationship Summary

The extracted relationships indicate the following planning arrangement:

- The **Master Bedroom** is adjacent to both the **Master Bathroom** and the **Master W.I.C.**
- **Bedroom #2** is adjacent to **Bathroom #2**.
- **Bedroom #3** is adjacent to **Bathroom #3**.
- The **Kitchen** is adjacent to the **Living/Dining Room**.
- The **Living/Dining Room** is adjacent to the **Terrace**.
- Access from the **Unit** to **Elevator #1** and **Elevator #2** is identified as occurring via the **Vestibule**.

The JSON does not provide a complete room-to-room circulation diagram. Relationships not listed should be treated as **not provided**, rather than as evidence that no connection or adjacency exists.

---

## 13. Drawing References / Details

No drawing references or detail references were extracted.

| Reference Category | Status |
|---|---|
| Detail callouts | 0 extracted |
| Section references | 0 extracted |
| Elevation references | 0 extracted |
| Enlarged plan references | 0 extracted |
| Consultant drawing references | 0 extracted |
| Specification references | 0 extracted |
| Sheet cross-references | 0 extracted |
| Door schedule references | 0 extracted |
| Window schedule references | 0 extracted |
| Finish schedule references | 0 extracted |

The sheet number, sheet title, and discipline were not provided. Consequently, the drawing cannot be cross-referenced to a larger sheet index or document set based solely on the supplied JSON.

---

## 14. Important Measurements and Areas Summary

### Unit Areas

| Measurement | Imperial Value | Metric Value |
|---|---:|---:|
| **Total area** | **1,885 sq.ft.** | **175 sq.m** |
| **A/C area** | **1,643 sq.ft.** | **153 sq.m** |
| **Terrace area** | **242 sq.ft.** | **22 sq.m** |

### Room Dimensions

| Space | Imperial Dimension | Metric Dimension |
|---|---|---|
| **Master Bedroom** | **11'-10" x 14'-0"** | **3.6 m x 4.3 m** |
| **Bedroom #2** | **10'-4" x 12'-0"** | **3.2 m x 3.7 m** |
| **Bedroom #3** | **10'-5" x 12'-0"** | **3.2 m x 3.7 m** |
| **Office/Family Room** | **9'-0" x 11'-0"** | **2.75 m x 3.35 m** |
| **Living/Dining Room** | **14'-0" x 36'-0"** | **4.3 m x 11.0 m** |

### Dimensional Caution

The drawing explicitly states that all dimensions are approximate and that floor plans and development plans are subject to change. No additional calculations or inferred dimensions are included in this report.

Areas for individual rooms were not provided. No room areas have been calculated from the listed dimensions.

---

## 15. Compliance / Life Safety Information

No code, compliance, or life safety information was extracted from the supplied JSON.

### Information Not Provided

The data does not identify:

- Building code edition
- Applicable jurisdiction
- Occupancy classification
- Construction type
- Fire-resistance ratings
- Rated wall or floor assemblies
- Means of egress calculations
- Exit access arrangement
- Exit width
- Travel distances
- Dead-end corridors
- Stair locations or stair ratings
- Elevator fire-rating information
- Accessible route requirements
- Accessible clearances
- Accessible bathroom requirements
- Emergency lighting
- Exit signage
- Fire alarm devices
- Smoke detectors
- Carbon monoxide detectors
- Fire sprinkler systems
- Fire department access
- Guardrails or handrails
- Terrace edge protection
- Emergency egress windows
- Required ventilation
- Plumbing fixture counts

The extraction lists **0 stairs extracted**, but this should not be interpreted as confirmation that the building or surrounding floor plan contains no stairs. The supplied data only indicates that no stair records were included in the extracted JSON.

Similarly, no doors or windows were extracted, but their absence from the JSON does not establish that the physical unit lacks doors or windows.

---

## 16. Data Gaps / Extraction Limitations

The following limitations apply to the supplied drawing data.

### Project and Sheet Metadata

- Project number was not provided.
- Sheet number was not provided.
- Sheet title was not provided.
- Discipline was not provided.
- Only the drawing title **Unit 03** was provided.
- The drawing set index and related sheets were not provided.

### Geometric and Dimensional Information

- Only five individual room dimension records were provided.
- Dimensions for ten listed spaces were not provided.
- No wall thicknesses were provided.
- No door or window dimensions were provided.
- No ceiling heights or vertical dimensions were provided.
- No structural dimensions were provided.
- No grid system was extracted.
- No dimensions for the elevators or vestibule were provided.
- No terrace length, width, or edge dimensions were provided.

### Openings and Circulation

- No doors were extracted.
- No windows were extracted.
- No opening types or locations were provided.
- Door swings and hardware were not provided.
- Egress paths were not provided.
- Stair information was not provided.
- The relationship data identifies elevator access via the vestibule, but does not provide a complete circulation diagram.

### Systems and Construction

- No structural columns were extracted.
- No materials or finishes were provided.
- No fixture locations or schedules were provided.
- No mechanical equipment locations were provided.
- No electrical information was provided.
- No plumbing information was provided.
- No fire protection information was provided.
- No acoustic, waterproofing, or performance criteria were provided.

### Code and Compliance

- No code analysis was included.
- No occupancy or life safety classification was provided.
- No accessibility analysis was provided.
- No rated construction information was provided.
- No egress or emergency systems information was provided.

### Interpretation Limitations

- The annotation states **“3 1/2 Bathrooms + Office,”** while the room list includes Master Bathroom, Bathroom #2, Bathroom #3, and Powder Room. The supplied JSON does not explain the counting convention.
- The north arrow is noted as shown, but its actual orientation and location are not represented in the extracted data.
- The extracted dimensions are subject to the drawing’s note that all dimensions are approximate.
- A zero extraction count means **0 extracted**, not necessarily that the physical element is absent.
- No information has been inferred or calculated beyond the values explicitly supplied.

---

## 17. Final Human-Readable Summary

The supplied drawing is a **residential unit floor plan** for **Unit 03** at **Aria Reserve Miami - Skyview Residences**, associated with **Levels 51-56**. The drawing is documented on Page 1 and has an extraction status of **ok**.

The unit schedule identifies **15 rooms or spaces**, including:

- Master Bedroom
- Master Bathroom
- Master W.I.C.
- Bedroom #2
- Bedroom #3
- Bathroom #2
- Bathroom #3
- Office/Family Room
- Living/Dining Room
- Kitchen
- Powder Room
- Foyer
- Vestibule
- Linen
- Terrace

The drawing annotation identifies the unit as having **3 Bedrooms** and **3 1/2 Bathrooms + Office**. The unit also includes access to **Elevator #1** and **Elevator #2 via Vestibule**.

The extracted area information is:

- **Total area:** **1,885 sq.ft.; 175 sq.m**
- **A/C area:** **1,643 sq.ft.; 153 sq.m**
- **Terrace area:** **242 sq.ft.; 22 sq.m**

Room dimensions are provided for the Master Bedroom, Bedroom #2, Bedroom #3, Office/Family Room, and Living/Dining Room. Dimensions for the remaining listed spaces were not provided.

The wall information identifies **exterior perimeter walls** at the unit perimeter and **interior partitions** throughout the unit. No wall thicknesses, wall assemblies, finishes, or ratings were supplied.

No door, window, column, stair, elevation, material, finish, or detailed building-system records were extracted. These zero counts represent **0 extracted** and should not be interpreted as confirmation that those elements are physically absent.

The extracted space relationships indicate that the Master Bedroom is adjacent to the Master Bathroom and Master W.I.C.; Bedroom #2 is adjacent to Bathroom #2; Bedroom #3 is adjacent to Bathroom #3; the Kitchen is adjacent to the Living/Dining Room; and the Living/Dining Room is adjacent to the Terrace. Access to both elevators is identified through the Vestibule.

Finally, the drawing includes the qualification that:

> **“All dimensions are approximate and all floor plans and development plans are subject to change.”**

Accordingly, the extracted information should be used as a documented summary of the supplied plan data, not as a substitute for a complete, current, issued architectural or construction drawing set.