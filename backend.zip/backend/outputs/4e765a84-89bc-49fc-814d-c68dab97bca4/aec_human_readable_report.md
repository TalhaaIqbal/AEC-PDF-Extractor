# AEC Drawing Extraction Report

## 1. Project / Drawing Overview

### Project Information

| Item | Extracted information |
|---|---|
| **Project name** | **RESTAURANT** |
| Project number | Not provided |
| Discipline | Architectural |
| Drawing title | Restaurant |
| Drawing type | Floor plan / egress plan |
| Sheet number | **A-1** |
| Sheet title | **FLOOR PLAN / EGRESS PLAN** |
| Page | **1** |
| Extraction status | OK |

The supplied drawing data represents a single architectural sheet for a restaurant project. Sheet **A-1** is identified as a **Floor Plan / Egress Plan** and includes room or space designations, wall types, doors, dimensions, elevations, equipment labels, annotations, material information, construction notes, egress information, and drawing references.

No project number, level designation, grid system, or additional sheets were provided in the extracted data.

---

## 2. Overall Element Count

The following counts represent extracted objects or categories in the supplied JSON. A count of zero means **0 extracted** and does not establish that the physical drawing contains none of those elements.

| Category | Extracted count | Notes |
|---|---:|---|
| Sheets | 1 | Sheet A-1 |
| Levels | 0 extracted | No levels provided |
| Grids | 0 extracted | No grid information provided |
| Rooms / spaces | 11 | Includes 10 numbered spaces and one unnumbered trash enclosure |
| Numbered rooms / spaces | 10 | Room numbers 101 through 110 |
| Unnumbered spaces | 1 | Trash enclosure |
| Wall types | 4 | Existing and new wall categories |
| Door types | 3 | Swing, double, and exit doors |
| Windows | 0 extracted | No window data provided |
| Columns | 0 extracted | No column data provided |
| Stairs | 0 extracted | No stair data provided |
| Dimension entries | 10 | Includes linear dimensions, a bench length, and angular values |
| Elevation entries | 2 | One N.G.V.D. elevation and one A.F.F. opening elevation |
| Annotations / callouts | 10 | Equipment, egress, flood barrier, finish, and construction callouts |
| Drawing references / details | 6 | References A-1, A-2 (Assembly), and details 1 through 4 |
| Material entries | 3 | Drywall, metal stud framing, and ceramic tile |
| General / construction notes | 9 | Includes coordination, permitting, egress, and verification requirements |
| Relationship entries | 6 | Adjacency, circulation, and flood protection relationships |

---

## 3. Rooms / Spaces

The drawing data identifies restaurant support, dining, service, preparation, restroom, and entrance-related spaces. All listed spaces are associated with page **1** of sheet **A-1**.

### Room and Space Schedule

| Number | Name | Extracted area | Function / description |
|---|---|---:|---|
| **101** | **WAITING AREA** | **140 SQFT** | Fixed-seat waiting area |
| **102** | **WALK IN COOLER** | **80 SQFT** | Function not provided |
| **103** | **RESTROOM** | Not provided | Function not provided |
| **104** | **RESTROOM** | Not provided | Function not provided |
| **105** | **COUNTER** | Not provided | Function not provided |
| **106** | **DINING** | **100 SQFT** | Function not provided |
| **107** | **DINING** | **350 SQFT** | Function not provided |
| **108** | **PIZZA AREA** | **240 SQFT** | Function not provided |
| **109** | **PREP AREA** | **80 SQFT** | Function not provided |
| **110** | **PREP AREA** | **46 SQFT** | Function not provided |
| Not assigned | **TRASH ENCLOSURE** | Not provided | Function not provided |

### Space Observations

- **Waiting Area 101** is identified as a **fixed-seat waiting area** and has an extracted area of **140 SQFT**.
- **Walk In Cooler 102** has an extracted area of **80 SQFT**.
- Two restroom spaces are identified as **Restroom 103** and **Restroom 104**.
- **Counter 105** is identified as a distinct space or area adjacent to dining functions.
- Two dining spaces are shown:
  - **Dining 106**, with an extracted area of **100 SQFT**
  - **Dining 107**, with an extracted area of **350 SQFT**
- **Pizza Area 108** has an extracted area of **240 SQFT**.
- Two preparation areas are shown:
  - **Prep Area 109**, with an extracted area of **80 SQFT**
  - **Prep Area 110**, with an extracted area of **46 SQFT**
- A **Trash Enclosure** is included in the extraction but does not have a room number or area.
- No areas were provided for the restrooms, counter, or trash enclosure.
- The extracted data does not identify occupancy values for individual rooms.

---

## 4. Dimensions

The following dimension values were extracted from sheet **A-1**, page **1**. Values are reproduced as supplied and have not been converted or recalculated.

### Extracted Dimensions and Measurements

| Extracted value | Type / description |
|---|---|
| **2'-4"** | Linear dimension; specific application not provided |
| **4'-5"** | Linear dimension; specific application not provided |
| **4'-0"** | Linear dimension; specific application not provided |
| **6'-3"** | Linear dimension; specific application not provided |
| **7'-4"** | Linear dimension; specific application not provided |
| **8'-8"** | Linear dimension; specific application not provided |
| **15'-6"** | Linear dimension; specific application not provided |
| **8'-0" LF bench** | Bench length |
| **22°** | Angular dimension |
| **45°** | Angular dimension |

### Dimensioning Convention

The drawing note states:

> **All dimensions are made from face of frame to face of frame unless otherwise noted.**

The extracted data does not identify the exact geometric location or endpoints for each of the linear dimensions. Accordingly, the dimension values should be used as extracted, but their specific application cannot be assigned beyond the descriptions provided.

---

## 5. Wall Information

Four wall categories were extracted from the floor plan / egress plan.

| Wall type | Description |
|---|---|
| **Existing exterior wall** | Existing exterior wall to remain |
| **Existing 2-hour fire-rated partition** | Description beyond the wall type was not provided |
| **New partition wall** | Typical new **3 5/8 inch, 25 gauge metal stud partition** |
| **New low wall** | Typical **42 inch high low wall** |

### Wall-Related Material Information

The materials data identifies the following wall construction information:

- **5/8 inch drywall** is identified for **partition walls**.
- **1-5/8 inch metal stud framing at 24 inches on center** is identified for **partition walls**.
- The new partition wall description separately identifies a typical **3 5/8 inch, 25 gauge metal stud partition**.
- A **new low wall** is identified as typically **42 inches high**.
- An **existing 2-hour fire-rated partition** is shown, but the specific assembly, rating documentation, or construction layers were not provided.

The extracted data does not establish exact wall locations, lengths, wall tags, or a complete wall assembly schedule.

---

## 6. Doors / Windows / Openings

### Doors

Three door categories were extracted.

| Door type | Extracted description |
|---|---|
| **Swing door** | Doors shown at restrooms, service areas, dining areas, and exits |
| **Double door** | Double entry doors shown at the north waiting-area entrance |
| **Exit door** | Egress doors with swing direction indicated |

### Door and Egress Information

- Swing doors are identified at:
  - Restrooms
  - Service areas
  - Dining areas
  - Exits
- Double entry doors are identified at the **north waiting-area entrance**.
- Exit doors are identified as egress doors with their **swing direction indicated**.
- The extraction does not provide individual door numbers, door widths, hardware sets, ratings, or detailed door schedules.
- Exact door locations and quantities by type are not provided beyond the identified door categories and descriptions.

### Windows

- **0 windows extracted.**
- This does not establish that the physical drawing contains no windows; no window objects or window schedule information were supplied in the extracted JSON.

### Other Openings

The drawing includes the following extracted opening information:

- **4' x 4' opening, 4' A.F.F.**
  - Location: **Service/prep area**
- A separate elevation callout identifies an **opening elevation of 4' A.F.F.**
- The extraction does not specify the opening type, framing, sill condition, head condition, or whether the 4' x 4' opening and the 4' A.F.F. elevation refer to the same opening.

---

## 7. Equipment / Fixtures / Building Systems

The following equipment and building-system labels were extracted.

| Label / item | Extracted location or description |
|---|---|
| **AHU** | Pizza/prep area |
| **AHU** | Walk-in cooler/service area |
| **OVEN** | Pizza area |
| **W.H.** | Prep area |
| **8'-0" LF bench** | Bench length extracted; specific location not provided |
| Wall-mounted fire extinguisher | Locations identified by egress-plan notation; exact individual locations not provided |
| Flood barrier | North entrance and south service area |

### Equipment Coordination

The construction notes require coordination of light fixtures with:

- Mechanical equipment
- Sprinkler equipment
- Structural members

Additional lighting coordination requirements include:

- Switching type and locations are to be coordinated with the tenant before installation.
- Accent lighting location is to be coordinated with the tenant before installation.

The extracted data does not include equipment schedules, capacities, manufacturers, utility connections, mechanical system details, sprinkler layouts, or electrical circuit information.

---

## 8. Annotations / Callouts

The following annotations and callouts were extracted from page **1**.

| Annotation / callout | Location or description |
|---|---|
| **FLOOD BARRIER** | North entrance and south service area |
| **PROVIDE SHOP DRAWINGS FOR APPROVAL** | Built-in millwork |
| **PROVIDE CERAMIC TILE 4' A.F.F.** | Service/restroom area |
| **ALIGN FACES OF FINISHES** | Restroom/service area |
| **4' x 4' OPENING, 4' A.F.F.** | Service/prep area |
| **AHU** | Pizza/prep area and walk-in cooler/service area |
| **OVEN** | Pizza area |
| **W.H.** | Prep area |
| **DENOTES PATH OF EGRESS** | Egress plan |
| **DENOTES WALL MOUNTED FIRE EXTINGUISHER** | Egress plan |

### Interpretation of Extracted Callouts

- Flood barriers are indicated at the **north entrance** and **south service area**.
- Built-in millwork requires shop drawings for approval.
- Ceramic tile is required in the service/restroom area up to **4' A.F.F.**
- Finish faces are to be aligned in the restroom/service area.
- A **4' x 4' opening** is identified at **4' A.F.F.** in the service/prep area.
- AHU labels occur in the pizza/prep area and walk-in cooler/service area.
- An oven is identified in the pizza area.
- A water-heater abbreviation, **W.H.**, is identified in the prep area.
- The egress plan includes a notation for the path of egress and a notation identifying wall-mounted fire extinguishers.

---

## 9. Elevations

Two elevation-related values were extracted from the drawing.

| Value | Description / location |
|---|---|
| **+8.1' N.G.V.D.** | Waiting area / main dining zone |
| **4' A.F.F.** | Opening elevation |

### Elevation Notes

- The waiting area / main dining zone has an extracted elevation of **+8.1' N.G.V.D.**
- An opening elevation of **4' A.F.F.** is identified.
- The notation **N.G.V.D.** and the notation **A.F.F.** are reproduced as supplied in the drawing extraction.
- The data does not provide a complete elevation datum explanation, floor elevation schedule, ceiling elevation schedule, or vertical section information.
- The **4' A.F.F.** opening elevation is also associated with the service/prep area opening callout, but the extraction does not definitively state whether every 4' A.F.F. reference applies to the same opening.

---

## 10. Materials / Finishes

### Extracted Materials

| Material | Application |
|---|---|
| **5/8 inch drywall** | Partition walls |
| **1-5/8 inch metal stud framing at 24 inches on center** | Partition walls |
| **Ceramic tile** | Service/restroom area, to **4 feet above finished floor** |

### Finish Requirements

The extracted annotations and material data identify the following finish requirements:

- Partition walls include **5/8 inch drywall**.
- Partition wall framing includes **1-5/8 inch metal studs at 24 inches on center**.
- The service/restroom area is to receive **ceramic tile to 4 feet above finished floor**.
- Finish faces are to be aligned in the restroom/service area.
- The drawing does not provide a complete finish schedule, color schedule, product specification, grout information, substrate requirements, or transition details.

---

## 11. Construction / General Notes

The following notes were extracted from sheet **A-1**.

### Coordination Notes

1. **All dimensions are made from face of frame to face of frame unless otherwise noted.**
2. The contractor shall coordinate all light fixtures with mechanical equipment, sprinkler equipment, and structural members.
3. The contractor shall coordinate switching type and locations with the tenant prior to installation.
4. The contractor shall coordinate accent lighting location with the tenant prior to installation.

### Fire Protection and Egress Notes

5. The contractor shall provide fire extinguishers as required by the plans and fire inspector.
6. Egress requirements shall comply with **NFPA 101 Chapter 5, Sections 7-2.1 and 38-22.2**.

### Verification and Submittal Notes

7. The contractor is to verify all dimensions and contact the architect with discrepancies.
8. The contractor shall field verify and provide shop drawings for all millwork; approval is required by the owner and architect.

### Permitting Note

9. A separate permit is required for **flood barriers and walk-in coolers**.

These notes should be read together with the plan annotations, referenced details, and any applicable project documents. The extracted data does not include additional specifications, code analysis, permit documents, or inspection requirements beyond the notes listed above.

---

## 12. Space Relationships

The extraction identifies six relationships between spaces or building elements.

| From | To | Relationship |
|---|---|---|
| **WAITING AREA 101** | **DINING 106 and DINING 107** | Adjacent/connected public circulation |
| **PIZZA AREA 108** | **PREP AREA 109 and PREP AREA 110** | Adjacent food preparation areas |
| **COUNTER 105** | **DINING 106** | Adjacent service and dining areas |
| **RESTROOM 103** | **RESTROOM 104** | Adjacent restroom rooms |
| **DINING 107** | **WAITING AREA 101** | Connected by egress/circulation path |
| **Flood barriers** | **Building entrances and service areas** | Flood protection elements shown at exterior openings |

### Circulation and Functional Relationships

- The waiting area is connected to or adjacent to both dining areas, supporting public circulation.
- Dining 107 is specifically identified as connected to Waiting Area 101 by an egress/circulation path.
- Counter 105 is adjacent to Dining 106, establishing a service-to-dining relationship.
- Pizza Area 108 is adjacent to Prep Areas 109 and 110, indicating a food preparation relationship.
- Restrooms 103 and 104 are adjacent to one another.
- Flood protection elements are associated with building entrances and service areas, including the north entrance and south service area.

The extracted data does not define detailed circulation widths, travel distances, occupancy loads, accessible routes, or separation distances.

---

## 13. Drawing References / Details

Six drawing references or detail callouts were extracted from page **1**.

| Reference | Description |
|---|---|
| **A-1** | Restroom plan and interior detail callouts |
| **A-2 (ASSEMBLY)** | Occupancy calculation reference |
| **1** | Floor plan / egress plan detail |
| **2** | Enlarged restroom plan |
| **3** | Interior elevation |
| **4** | Vault drop ceiling detail |

### Reference Notes

- **A-1** is referenced for restroom plan and interior detail callouts, consistent with the supplied sheet number.
- **A-2 (ASSEMBLY)** is identified as an occupancy calculation reference.
- Detail **1** is identified as a floor plan / egress plan detail.
- Detail **2** is an enlarged restroom plan.
- Detail **3** is an interior elevation.
- Detail **4** is a vault drop ceiling detail.
- No separate sheet data for A-2 or additional referenced sheets was supplied in the JSON.

---

## 14. Important Measurements and Areas Summary

### Extracted Space Areas

| Space | Area |
|---|---:|
| Waiting Area 101 | **140 SQFT** |
| Walk In Cooler 102 | **80 SQFT** |
| Dining 106 | **100 SQFT** |
| Dining 107 | **350 SQFT** |
| Pizza Area 108 | **240 SQFT** |
| Prep Area 109 | **80 SQFT** |
| Prep Area 110 | **46 SQFT** |
| Restroom 103 | Not provided |
| Restroom 104 | Not provided |
| Counter 105 | Not provided |
| Trash Enclosure | Not provided |

The extracted JSON provides areas for seven spaces and does not provide areas for the two restrooms, counter, or trash enclosure. No combined area has been calculated in this report.

### Extracted Linear Dimensions

- **2'-4"**
- **4'-5"**
- **4'-0"**
- **6'-3"**
- **7'-4"**
- **8'-8"**
- **15'-6"**
- **8'-0" LF bench**

### Extracted Angular Dimensions

- **22°**
- **45°**

### Openings and Vertical Measurements

- **4' x 4' opening**
- Opening elevation: **4' A.F.F.**
- Ceramic tile height: **4 feet above finished floor**
- New low wall height: **42 inches**
- Waiting area / main dining zone elevation: **+8.1' N.G.V.D.**

### Other Construction Measurements

- New partition wall: **3 5/8 inch, 25 gauge metal stud partition**
- Partition wall drywall: **5/8 inch**
- Metal stud framing: **1-5/8 inch studs at 24 inches on center**
- Bench length: **8'-0" LF**

---

## 15. Compliance / Life Safety Information

The drawing is identified as a **Floor Plan / Egress Plan** and includes life-safety-related annotations and notes.

### Egress

- The plan includes a notation stating **DENOTES PATH OF EGRESS**.
- Exit doors are identified, with swing direction indicated.
- The extracted relationship data identifies a connected egress/circulation path between **Dining 107** and **Waiting Area 101**.
- Egress requirements are stated to comply with:
  - **NFPA 101 Chapter 5**
  - **Section 7-2.1**
  - **Section 38-22.2**

### Fire Protection

- The plan identifies wall-mounted fire extinguishers through the notation:
  - **DENOTES WALL MOUNTED FIRE EXTINGUISHER**
- The contractor is required to provide fire extinguishers as required by the plans and the fire inspector.
- An existing **2-hour fire-rated partition** is identified.
- The extracted data does not provide the number, rating, exact locations, mounting heights, or inspection requirements for the fire extinguishers.

### Flood Protection

- **FLOOD BARRIER** callouts are located at:
  - North entrance
  - South service area
- Flood barriers are described as flood protection elements at exterior openings.
- A separate permit is required for flood barriers and walk-in coolers.

### Occupancy Information

- Reference **A-2 (ASSEMBLY)** is identified as an occupancy calculation reference.
- No occupancy calculation, occupant load, occupant load factor, assembly classification, or egress capacity values were included in the supplied extraction.

### Accessibility and Other Code Information

- No accessibility compliance information was extracted.
- No accessible route, accessible restroom dimensions, turning clearances, fixture clearances, or accessible hardware information was provided.
- No complete fire-resistance, sprinkler, alarm, emergency lighting, exit signage, or means-of-egress capacity information was provided.

---

## 16. Data Gaps / Extraction Limitations

The following information was not provided or could not be determined from the supplied JSON.

### Project and Sheet Data Gaps

- Project number is not provided.
- Only one sheet, **A-1**, is included in the extraction.
- Referenced sheet or detail information for **A-2 (ASSEMBLY)** and other referenced documents is not included.
- No drawing scale, issue date, revision history, designer, architect, owner, or consultant information is provided.
- No level names or floor identifiers are provided.
- No grid system is provided.

### Spatial and Geometric Data Gaps

- Exact room boundary geometry is not provided.
- Exact locations of walls, doors, equipment, openings, and fixtures are not represented in the JSON.
- The specific application of most extracted dimensions is not identified.
- No complete dimension strings or overall building dimensions are provided.
- No room areas are provided for Restrooms 103 and 104, Counter 105, or the Trash Enclosure.
- No total project area or total extracted area is provided.
- No occupancy load values are provided.

### Wall, Door, Window, and Opening Gaps

- Wall quantities, lengths, locations, tags, and complete assemblies are not provided.
- The existing 2-hour fire-rated partition lacks a detailed assembly description.
- Door quantities, widths, heights, hardware, ratings, and exact locations are not provided.
- Windows are **0 extracted**, but this does not confirm that no windows exist physically.
- Window sizes, types, glazing, and locations are not provided.
- The detailed construction of the 4' x 4' opening is not provided.

### Equipment and Systems Gaps

- No mechanical equipment schedules or capacities are provided for the AHUs.
- No oven specifications or utility requirements are provided.
- The abbreviation **W.H.** is present in the prep area, but no expanded description or equipment data is provided.
- No electrical, plumbing, HVAC, sprinkler, or fire alarm layouts are included.
- No light fixture schedule or switching diagram is provided.
- No structural information is provided.

### Materials and Finish Gaps

- No complete finish schedule is included.
- No product specifications, colors, patterns, substrates, grout, transitions, or installation requirements are provided.
- No ceiling finish or ceiling height schedule is included, although a vault drop ceiling detail is referenced.
- No flooring or wall finish information beyond the extracted ceramic tile requirement is provided.

### Code and Compliance Gaps

- No occupancy calculations are provided despite the reference to **A-2 (ASSEMBLY)**.
- No occupant loads or egress capacity calculations are provided.
- No travel distances, exit separation calculations, or exit access widths are provided.
- No accessibility analysis is provided.
- No fire extinguisher count or spacing is provided.
- No sprinkler or fire alarm information is provided.
- No permit documents or authority-having-jurisdiction comments are included.

### Interpretation Limitations

- Extracted information is limited to the supplied structured JSON.
- A value of **0 extracted** indicates that no corresponding object was supplied in the extraction; it does not prove that the drawing or building contains none of that element.
- Missing room areas, dimensions, equipment details, and code information should be treated as **not provided**, not as zero or not applicable.
- The exact physical arrangement should be verified against the original drawing sheet and referenced details.

---

## 17. Final Human-Readable Summary

The supplied AEC data represents an architectural restaurant floor plan and egress plan on sheet **A-1**, titled **FLOOR PLAN / EGRESS PLAN**. The plan identifies ten numbered rooms or spaces, numbered **101 through 110**, along with an unnumbered **Trash Enclosure**.

The principal public and operational spaces include a **140 SQFT Waiting Area 101**, an **80 SQFT Walk In Cooler 102**, two restrooms, a counter, two dining areas measuring **100 SQFT** and **350 SQFT**, a **240 SQFT Pizza Area**, and two prep areas measuring **80 SQFT** and **46 SQFT**. The waiting area is described as a fixed-seat waiting area. The plan establishes adjacency between the waiting area and dining areas, between the pizza area and prep areas, between the counter and Dining 106, and between the two restrooms.

Wall information includes an existing exterior wall to remain, an existing **2-hour fire-rated partition**, a new typical **3 5/8 inch, 25 gauge metal stud partition**, and a new typical **42 inch high low wall**. Partition wall materials include **5/8 inch drywall** and **1-5/8 inch metal stud framing at 24 inches on center**.

The drawing identifies swing doors, double entry doors at the north waiting-area entrance, and exit doors with swing directions indicated. No windows were extracted. A **4' x 4' opening at 4' A.F.F.** is identified in the service/prep area.

Equipment and building-system callouts include **AHU** labels in the pizza/prep area and walk-in cooler/service area, an **OVEN** in the pizza area, and **W.H.** in the prep area. A bench length of **8'-0" LF** is also extracted. Flood barriers are identified at the north entrance and south service area, and a separate permit is required for flood barriers and walk-in coolers.

Key extracted dimensions include **2'-4"**, **4'-5"**, **4'-0"**, **6'-3"**, **7'-4"**, **8'-8"**, and **15'-6"**, along with angular values of **22°** and **45°**. The waiting area / main dining zone has an extracted elevation of **+8.1' N.G.V.D.** The drawing also identifies a **4' A.F.F.** opening elevation and ceramic tile extending to **4 feet above finished floor** in the service/restroom area.

Life-safety information includes a designated path of egress, exit door swing indications, wall-mounted fire extinguisher notation, and a requirement to comply with **NFPA 101 Chapter 5, Sections 7-2.1 and 38-22.2**. Reference **A-2 (ASSEMBLY)** is identified for occupancy calculations, but no actual occupancy calculation or occupant load values are included in the supplied extraction.

The drawing notes require coordination of light fixtures with mechanical, sprinkler, and structural elements; coordination of switching and accent lighting with the tenant; provision of fire extinguishers as required by the plans and fire inspector; field verification of dimensions; architect notification of discrepancies; and shop drawings for millwork subject to owner and architect approval. Exact geometry, quantities, detailed schedules, code calculations, accessibility information, and several referenced drawing contents remain unavailable from the extracted JSON and require review of the original drawing documents.