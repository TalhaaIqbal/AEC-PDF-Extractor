# AEC Drawing Extraction Report  
## Villa Miami / Villa Mezzo

---

## 1. Project / Drawing Overview

### Project Identification

| Item | Extracted information |
|---|---|
| Project name | **Villa Miami / Villa Mezzo** |
| Project number | Not provided |
| Primary discipline | Architecture / Architectural |
| Drawing content | Residential floor plans |
| Total extracted pages | **8** |
| Level information | **Villa Piano**, page 8 |
| Grid information | No grids extracted |
| Elevation information | No elevations extracted |
| Drawing references | No drawing references extracted |

The supplied drawing set consists of eight extracted architectural or architectural-designated residential floor plan pages associated with Villa Miami / Villa Mezzo. The pages include multiple Villa Mezzo plan configurations and two Villa Piano plan pages.

All eight pages have a detection status of **“ok.”**

### Drawing and Sheet Index

| Page | Sheet number | Sheet title | Drawing title | Discipline | Drawing type |
|---:|---|---|---|---|---|
| 1 | Not provided | VILLA MEZZO | PRIMARY EAST 01B | Architecture | Residential floor plan |
| 2 | 01B | Villa Mezzo - Primary West | Residential Floor Plan | Architecture | Floor plan |
| 3 | Not provided | PRIMARY EAST 02A | Villa Mezzo Floor Plan | Architectural | Residential floor plan |
| 4 | Not provided | PRIMARY EAST 02B | Villa Mezzo Floor Plan | Architecture | Floor plan |
| 5 | 02A | PRIMARY WEST 02A | Villa Mezzo | Architectural | Floor plan |
| 6 | Not provided | PRIMARY WEST 02B | Villa Mezzo | Architecture | Floor plan |
| 7 | Not provided | VILLA PIANO | Villa Miami Floor Plan | Architectural | Floor plan |
| 8 | Not provided | Villa Piano | Villa Miami - Villa Piano | Architecture | Floor plan |

### Level Information

Only one level record was extracted:

| Level name | Page |
|---|---:|
| Villa Piano | 8 |

The JSON does not provide a complete level schedule or identify the vertical elevation of the Villa Piano level. The extracted stair information indicates vertical circulation between the residence and another level, but the specific connected level is not identified.

---

## 2. Overall Element Count

The following quantities represent **extracted element records**, not verified physical quantities in the building. A count of zero means **“0 extracted”** and should not be interpreted as confirmation that the physical drawing or building contains none.

| Element category | Extracted record count | Notes |
|---|---:|---|
| Sheets | 8 | Pages 1 through 8 |
| Levels | 1 | Villa Piano, page 8 |
| Grids | 0 extracted | No grids provided in the JSON |
| Rooms / spaces | 20 | Includes rooms, circulation spaces, terraces, and WC |
| Wall types | 2 | Exterior perimeter walls and interior partition walls |
| Door types | 2 | Interior doors and exterior terrace access doors |
| Window types | 1 | Exterior windows and glazed openings |
| Columns | 0 extracted | No column records provided |
| Stair types | 2 | West Stair and East Stair |
| Dimension categories | 4 | Interior area, exterior area, foyer area, and total area |
| Elevation records | 0 extracted | No elevations provided |
| Annotation types | 6 | Views, orientation, street, bay, and cove references |
| Material / finish records | 0 extracted | No materials or finishes provided |
| General note records | 3 | Program summaries |
| Relationship records | 7 | Adjacency, grouping, circulation, and access |
| Drawing references | 0 extracted | No detail or cross-reference records provided |

---

## 3. Rooms / Spaces

The room and space records below reflect the names, functions, aliases, dimensions, and page associations extracted from the JSON. Where a room appears on a page but no dimension is provided for that page, the absence of a dimension is identified as a data gap rather than as evidence that the space has no dimensions.

### Room and Space Schedule

| Space | Function / designation | Number or alias | Pages | Extracted dimensions |
|---|---|---|---|---|
| Primary Bedroom | Bedroom | — | 1–8 | Multiple variants; see detailed table below |
| Bedroom 2 | Bedroom | 2 | 1, 2, 3, 4, 5, 6, 8 | Multiple variants; page-specific data incomplete |
| Bedroom 3 | Bedroom | 3 | 1–8 | Multiple variants; see detailed table below |
| Bedroom 4 | Bedroom | 4 | 3, 5, 7, 8 | Dimensions extracted on pages 3, 5, and 7 only |
| Bedroom 5 | Bedroom | — | 7, 8 | **16' x 8'** |
| Primary Bathroom | Bathroom | — | 1–8 | **23'11" x 12'2"** on page 7; **23'1" x 11'2"** on page 8 |
| Walk-In Closet | — | WIC | 1, 2, 3, 5, 6, 7, 8 | Multiple variants; see detailed table below |
| Family Room | — | — | 1, 2, 4, 6, 7, 8 | Multiple variants; see detailed table below |
| Living/Dining | Living and dining | — | 1–6 | Multiple variants; see detailed table below |
| Living Room | — | — | 7, 8 | **25'9" x 24'8"** |
| Dining Room | — | — | 7, 8 | **32' x 16'7"** |
| Kitchen | Kitchen | — | 1–8 | Multiple variants; see detailed table below |
| Pantry | — | — | 1–8 | **9'7" x 6'10"** on pages 7 and 8 |
| Laundry | — | — | 1–8 | No room dimensions extracted |
| Service Foyer | Service circulation | — | 1–8 | No room dimensions extracted |
| Villa Foyer | Entry foyer | — | 1–8 | Multiple variants; see detailed table below |
| Powder Room | Powder room | PR | 1–8 | No room dimensions extracted |
| WC | Water closet | — | 3 | No room dimensions extracted |
| West Terrace | Private terrace | — | 1, 3, 6, 7, 8 | Multiple variants; city view |
| East Terrace | Private terrace | — | 1, 2, 3, 4, 6, 7, 8 | Multiple variants; bay view |

### Bedroom Information

#### Primary Bedroom

The Primary Bedroom is extracted on all eight pages. The following dimensional variants are associated with the identified pages:

| Dimension | Pages |
|---|---|
| **15'3" x 11'0"** | 3, 4 |
| **15'3" x 11'10"** | 1 |
| **14'2" x 16'1"** | 2, 6 |
| **14'2" x 16'11"** | 5 |
| **18' x 19'4"** | 7, 8 |

#### Bedroom 2

Bedroom 2 is extracted on pages 1, 2, 3, 4, 5, 6, and 8. The available dimensional variants are:

| Dimension | Pages |
|---|---|
| **12' x 11'10"** | 1 |
| **14'0" x 11'4"** | 2 |
| **12' x 11'0"** | 3 |
| **11'4" x 11'?** | 6 |
| **10'2" x 12'2"** | 8 |

The value **“11'4" x 11'?”** contains an uncertain or incomplete dimension exactly as extracted. No dimension is provided for Bedroom 2 on pages 4 or 5, even though the room is included in the overall room page list.

#### Bedroom 3

Bedroom 3 is extracted on all eight pages:

| Dimension | Pages |
|---|---|
| **12' x 16'7"** | 1 |
| **10'0" x 12'2"** | 2, 6 |
| **12'7" x 16'7"** | 3, 4 |
| **10'10" x 12'2"** | 5 |
| **12'6" x 11'10"** | 7 |

No Bedroom 3 dimension is listed for page 8.

#### Bedroom 4

Bedroom 4 is extracted on pages 3, 5, 7, and 8. Dimensions are provided for three of those pages:

| Dimension | Pages |
|---|---|
| **14'7" x 13'2"** | 3 |
| **11'3" x 12'2"** | 5 |
| **12' x 17'3"** | 7 |

No Bedroom 4 dimension is provided for page 8.

#### Bedroom 5

Bedroom 5 is extracted on pages 7 and 8, with the following dimension:

| Dimension | Pages |
|---|---|
| **16' x 8'** | 7, 8 |

### Bathroom, Closet, and WC Information

#### Primary Bathroom

The Primary Bathroom is identified on all eight pages. Dimensions are provided only for the Villa Piano pages:

| Dimension | Pages |
|---|---|
| **23'11" x 12'2"** | 7 |
| **23'1" x 11'2"** | 8 |

#### Walk-In Closet / WIC

The Walk-In Closet is also identified by the alias **WIC**. It is extracted on pages 1, 2, 3, 5, 6, 7, and 8.

| Dimension | Pages |
|---|---|
| **17' x 7'2"** | 7 |
| **15'9" x 11'10"** | 7 |
| **8'3" x 11'0"** | 8 |

No dimensions are provided for the Walk-In Closet on pages 1, 2, 3, 5, or 6.

#### WC

A **WC**, identified as a **Water closet**, is extracted on page 3 only. No dimension is provided.

#### Powder Room

The **Powder Room**, identified with the designation **PR**, is extracted on all eight pages. No dimension is provided.

### Living, Dining, and Family Spaces

#### Family Room

The Family Room is extracted on pages 1, 2, 4, 6, 7, and 8:

| Dimension | Pages |
|---|---|
| **19'8" x 17'** | 1 |
| **20'8" x 24'0"** | 2 |
| **20'3" x 12'4"** | 6 |
| **34'6" x 17'3"** | 7, 8 |

No Family Room dimension is listed for page 4.

#### Living/Dining

The Living/Dining space is identified with the function **“Living and dining”** and appears on pages 1 through 6:

| Dimension | Pages |
|---|---|
| **25'7" x 13'5"** | 1 |
| **32'10" x 17'3"** | 2, 5, 6 |
| **25'2" x 15'5"** | 3 |
| **25'2" x 15'9"** | 4 |

#### Living Room

The Living Room appears on pages 7 and 8:

| Dimension | Pages |
|---|---|
| **25'9" x 24'8"** | 7, 8 |

#### Dining Room

The Dining Room appears on pages 7 and 8:

| Dimension | Pages |
|---|---|
| **32' x 16'7"** | 7, 8 |

### Kitchen and Service Spaces

#### Kitchen

The Kitchen is extracted on all eight pages. The following dimensional variants are provided:

| Dimension | Pages |
|---|---|
| **27' x 22'** | 1 |
| **20'2" x 12'10"** | 2, 5, 6 |
| **27'2" x 12'2"** | 3, 4 |
| **20'2" x 10'0"** | 6 |
| **30'6" x 12'3"** | 7, 8 |

Page 6 has two Kitchen dimension variants recorded: **20'2" x 12'10"** and **20'2" x 10'0"**. The JSON does not explain whether these represent separate portions, alternate readings, or differing plan conditions.

#### Pantry

The Pantry is extracted on all eight pages. A dimension is provided for pages 7 and 8:

| Dimension | Pages |
|---|---|
| **9'7" x 6'10"** | 7, 8 |

No Pantry dimensions are provided for pages 1 through 6.

#### Laundry

The Laundry is extracted on all eight pages. No function beyond the room name and no dimensions are provided.

#### Service Foyer

The Service Foyer is extracted on all eight pages and is identified as **service circulation**. No dimensions are provided.

#### Villa Foyer

The Villa Foyer is extracted on all eight pages and is identified as an **entry foyer**:

| Dimension | Pages |
|---|---|
| **8'4" x 18'7"** | 1 |
| **8'4" x 19'7"** | 2, 3 |
| **8'4" x 9'7"** | 4, 8 |
| **8'4" x 9'** | 5 |
| **8'4" x 13'7"** | 6 |
| **8'4" x 7'** | 7 |

### Terrace Information

#### West Terrace

The West Terrace is identified as a **private terrace** with a **City view**. It appears on pages 1, 3, 6, 7, and 8.

| Dimension | Pages |
|---|---|
| **8'4" x 26'7"** | 1 |
| **8'4" x 26'2"** | 3, 6 |
| **8'4" x 5'2"** | 7 |

No West Terrace dimension is listed for page 8, despite the terrace being included in the page association.

#### East Terrace

The East Terrace is identified as a **private terrace** with a **Bay view**. It appears on pages 1, 2, 3, 4, 6, 7, and 8.

| Dimension | Pages |
|---|---|
| **9'8" x 26'?** | 1 |
| **9'8" x 26'2"** | 2, 3, 6 |
| **9'8" x 5'2"** | 7 |

The value **“9'8" x 26'?”** contains an uncertain or incomplete dimension exactly as extracted. No East Terrace dimension is provided for pages 4 or 8.

---

## 4. Dimensions

### Extracted Area Dimensions

The JSON provides interior, exterior, foyer, and total area information. These values are reported exactly as extracted and are not recalculated.

| Description | Extracted value | Pages |
|---|---|---|
| Interior area | **2,960-2,985 SF** | 1, 2 |
| Interior area | **2,936-2,972 SF** | 3, 4, 5, 6 |
| Interior area | **5,896-5,957 SF** | 7, 8 |
| Exterior area | **298-350 SF** | 1–6 |
| Exterior area | **596-700 SF** | 7, 8 |
| Foyer area | **185 SF** | 7, 8 |
| Total area | **3,281-3,316 SF** | 1, 2 |
| Total area | **3,267-3,302 SF** | 3–6 |
| Total area | **6,548-6,618 SF** | 7, 8 |

The JSON does not define whether the area ranges represent alternate unit configurations, plan alternatives, measurement tolerances, or ranges shown on the drawings.

### Room and Space Dimensions

Room dimensions are listed in the Rooms / Spaces section. All values are preserved in the extracted format, including values containing uncertainty markers such as **“?”**.

No dimensions were extracted for:

- Laundry
- Service Foyer
- Powder Room
- WC
- Several page-specific instances of rooms that are otherwise identified
- Some page-specific terrace and closet occurrences

The absence of a listed dimension should not be interpreted as evidence that the drawing contains no dimension for that space.

---

## 5. Wall Information

Two wall categories were extracted.

| Wall type | Description | Pages |
|---|---|---|
| Exterior perimeter walls | Enclose the residential floor plans and terrace edges. | 1–7 |
| Interior partition walls | Separate bedrooms, bathrooms, closets, kitchens, foyers, living spaces, and service areas. | 1–7 |

### Exterior Perimeter Walls

The exterior perimeter walls are described as enclosing the residential floor plans and terrace edges. The extracted record is associated with pages 1 through 7. Page 8 is not listed in the wall record, although page 8 contains a Villa Piano floor plan.

No wall thicknesses, construction assemblies, fire ratings, structural designations, or material descriptions are provided.

### Interior Partition Walls

Interior partition walls are described as separating:

- Bedrooms
- Bathrooms
- Closets
- Kitchens
- Foyers
- Living spaces
- Service areas

No partition thicknesses, acoustic ratings, fire-resistance ratings, or construction types are provided.

### Wall Data Limitations

The JSON provides wall categories and general descriptions only. It does not provide:

- Wall dimensions
- Wall tags
- Wall types by location
- Structural versus nonstructural designation
- Rated wall information
- Finish build-ups
- Detail references
- Page 8 wall records

---

## 6. Doors / Windows / Openings

### Doors

| Door type | Description | Pages |
|---|---|---|
| Interior doors | Interior hinged or swing doors throughout the residences. | 3–6 |
| Exterior terrace access doors | Doors serving the west and east terraces and associated living or bedroom areas. | 3–5 |

The extracted data does not provide door counts, door numbers, clear widths, rough openings, hardware, fire ratings, swing directions, or door schedules.

The relationship data confirms that exterior doors provide access between living or bedroom areas and the west and east terraces.

### Windows and Glazed Openings

| Window type | Description | Pages |
|---|---|---|
| Exterior windows and glazed openings | Perimeter glazing serving bedrooms, living areas, and terrace edges. | 2–6 |

No window counts, tags, sizes, sill heights, head heights, glazing types, performance requirements, or window schedules are provided.

### Columns

**0 extracted.**

This indicates that no column records were included in the supplied JSON. It does not establish that the physical plans contain no columns.

### Openings Data Limitations

The extraction does not include:

- Opening counts
- Door or window tags
- Opening dimensions
- Door and window schedules
- Curtain-wall information
- Railing or guard information at terraces
- Threshold details
- Door hardware
- Glazing performance
- Egress opening designations

---

## 7. Equipment / Fixtures / Building Systems

### Stairs

Two interior stair records were extracted:

| Stair | Type | Pages |
|---|---|---|
| West Stair | Interior stair | 1–8 |
| East Stair | Interior stair | 1–8 |

#### West Stair Locations

| Location description | Pages |
|---|---|
| West or lower-left central portion of plan | 1, 3, 5, 6 |
| Near the west side of the Villa Foyer | 4 |

#### East Stair Locations

| Location description | Pages |
|---|---|
| East or right-central portion of plan | 1, 3, 5, 6 |
| Near the east side of the Villa Foyer | 4 |

The relationship data describes the West Stair and East Stair as providing circulation between the residence and another level. The Villa Foyer is associated with the stairs.

No stair widths, riser heights, tread depths, landings, handrails, guardrails, stair tags, or connected-level identifiers are provided.

### Equipment and Fixtures

No dedicated equipment or fixture records were extracted. In particular, the JSON does not identify:

- Plumbing fixture counts or types
- Kitchen appliances
- Laundry equipment
- Mechanical equipment
- Electrical equipment
- Fire protection equipment
- Lighting fixtures
- HVAC terminals
- Water heaters
- Generators
- Elevators
- Specialty equipment

Room names such as Kitchen, Laundry, Bathroom, WC, and Powder Room identify spaces but do not provide fixture or equipment schedules.

---

## 8. Annotations / Callouts

The following annotations were extracted.

| Annotation text | Location or description | Pages |
|---|---|---|
| **CITY VIEW** | West side | 1–8 |
| **BAY VIEW** | East and/or south sides | 1–8 |
| **NORTH / NORTH ARROW** | Orientation indicator | 1–8 |
| **29TH STREET** | Site or contextual reference | 1, 3, 4, 5 |
| **BISCAYNE BAY** | Site or contextual reference | 3, 4, 5 |
| **LITTLE BLUE COVE** | Site or contextual reference | 4, 5 |

The West Terrace is associated with the City view, and the East Terrace is associated with the Bay view. These associations are also reflected in the space records.

No additional callout identifiers, keynote numbers, specification references, or construction detail callouts were extracted.

---

## 9. Elevations

**0 extracted.**

The supplied JSON contains no elevation records. The drawing set is identified as a collection of residential floor plans, and no exterior, interior, building, or sectional elevation information is included in the extraction.

No elevation heights, datum references, façade dimensions, parapet heights, floor-to-floor dimensions, or vertical finish information are provided.

---

## 10. Materials / Finishes

**0 extracted.**

No material or finish records were provided in the JSON.

The extraction contains no information regarding:

- Flooring
- Wall finishes
- Ceiling finishes
- Exterior cladding
- Roofing
- Countertops
- Cabinet materials
- Door or window materials
- Terrace finishes
- Paint colors
- Finish codes
- Finish schedules
- Material specifications

Room names and space functions do not establish finish materials.

---

## 11. Construction / General Notes

Three program summary notes were extracted.

| Program summary | Pages |
|---|---|
| **3 bedrooms, 3 bathrooms, 1 powder room, and 2 private terraces.** | 1, 2, 4, 6 |
| **4 bedrooms, 4 bathrooms, 1 powder room, and 2 private terraces.** | 3, 5, 7 |
| **5 bedrooms, 5 bathrooms, 1 powder room, and 2 private terraces.** | 8 |

These notes are reported as extracted and are not reconciled with the room records. For example, the room extraction identifies specific spaces such as Primary Bathroom, WC, and Powder Room, but it does not provide a complete bathroom count by page. The program summary should therefore be treated as the stated program information for each listed page grouping.

No general construction notes were provided regarding:

- Construction sequencing
- Demolition
- Existing conditions
- Structural systems
- Waterproofing
- Firestopping
- Insulation
- Accessibility
- Mechanical systems
- Electrical systems
- Plumbing systems
- Finish installation
- Quality control
- Tolerances
- Coordination requirements

---

## 12. Space Relationships

The following relationships were extracted.

### Kitchen and Service Spaces

The Kitchen is adjacent to the Pantry, Laundry, and Living/Dining or Dining Room.

**Pages:** 1–8

### Primary Bedroom Suite

The Primary Bedroom is adjacent to the Primary Bathroom and Walk-In Closet/WIC.

**Pages:** 1–8

### Living and East Terrace

The Living/Dining or Living Room is associated with the East Terrace and Bay view.

**Pages:** 1–8

### Family Room and West Terrace

The Family Room is associated with the West Terrace and City view.

**Pages:** 1, 4, 6, 7, 8

### Bedroom Grouping

Bedrooms are grouped along the north and/or west residential portion of the plan with nearby bathroom and closet areas.

**Pages:** 3, 5, 7, 8

### Vertical Circulation

The West Stair and East Stair provide circulation between the residence and another level. The Villa Foyer is associated with the stairs.

**Pages:** 1, 3, 4, 5, 6, 7, 8

### Terrace Access

Exterior doors provide access between living or bedroom areas and the West and East Terraces.

**Pages:** 3, 4, 5

The relationships are qualitative. The JSON does not provide exact door-to-room connectivity, circulation widths, or a complete adjacency matrix.

---

## 13. Drawing References / Details

**0 extracted.**

No drawing references, detail callouts, section references, elevation references, enlarged-plan references, or schedule references were provided.

The extracted JSON does not identify:

- Referenced detail numbers
- Section marks
- Elevation marks
- Wall section references
- Door or window schedule references
- Finish schedule references
- Structural or MEP coordination references
- Sheet-to-sheet callouts

---

## 14. Important Measurements and Areas Summary

### Primary Area Summary

| Plan grouping / pages | Interior area | Exterior area | Foyer area | Total area |
|---|---:|---:|---:|---:|
| Pages 1–2 | **2,960-2,985 SF** | **298-350 SF** | Not provided | **3,281-3,316 SF** |
| Pages 3–6 | **2,936-2,972 SF** | **298-350 SF** | Not provided | **3,267-3,302 SF** |
| Pages 7–8 | **5,896-5,957 SF** | **596-700 SF** | **185 SF** | **6,548-6,618 SF** |

### Selected Room Dimensions

| Space | Extracted dimensions |
|---|---|
| Primary Bedroom | **15'3" x 11'0"**; **15'3" x 11'10"**; **14'2" x 16'1"**; **14'2" x 16'11"**; **18' x 19'4"** |
| Bedroom 2 | **12' x 11'10"**; **14'0" x 11'4"**; **12' x 11'0"**; **11'4" x 11'?**; **10'2" x 12'2"** |
| Bedroom 3 | **12' x 16'7"**; **10'0" x 12'2"**; **12'7" x 16'7"**; **10'10" x 12'2"**; **12'6" x 11'10"** |
| Bedroom 4 | **14'7" x 13'2"**; **11'3" x 12'2"**; **12' x 17'3"** |
| Bedroom 5 | **16' x 8'** |
| Primary Bathroom | **23'11" x 12'2"**; **23'1" x 11'2"** |
| Walk-In Closet / WIC | **17' x 7'2"**; **15'9" x 11'10"**; **8'3" x 11'0"** |
| Family Room | **19'8" x 17'**; **20'8" x 24'0"**; **20'3" x 12'4"**; **34'6" x 17'3"** |
| Living/Dining | **25'7" x 13'5"**; **32'10" x 17'3"**; **25'2" x 15'5"**; **25'2" x 15'9"** |
| Living Room | **25'9" x 24'8"** |
| Dining Room | **32' x 16'7"** |
| Kitchen | **27' x 22'**; **20'2" x 12'10"**; **27'2" x 12'2"**; **20'2" x 10'0"**; **30'6" x 12'3"** |
| Pantry | **9'7" x 6'10"** |
| Villa Foyer | **8'4" x 18'7"**; **8'4" x 19'7"**; **8'4" x 9'7"**; **8'4" x 9'**; **8'4" x 13'7"**; **8'4" x 7'** |
| West Terrace | **8'4" x 26'7"**; **8'4" x 26'2"**; **8'4" x 5'2"** |
| East Terrace | **9'8" x 26'?**; **9'8" x 26'2"**; **9'8" x 5'2"** |

The values containing **“?”** are uncertain as extracted and should not be treated as fully verified dimensions without review of the source drawing.

---

## 15. Compliance / Life Safety Information

The supplied JSON does not contain explicit code-compliance or life-safety analysis.

### Information That Is Present

The extracted information identifies:

- Residential floor plans
- Bedrooms, bathrooms, a powder room, WC, and living/service areas
- Two interior stairs: West Stair and East Stair
- Exterior terrace access doors
- Interior doors
- Exterior windows and glazed openings
- A north arrow or north orientation annotation
- Program summaries stating bedroom, bathroom, powder room, and terrace quantities

### Information Not Provided

No explicit information is provided regarding:

- Occupant loads
- Means of egress calculations
- Required or provided exit widths
- Travel distances
- Common path of egress travel
- Exit access
- Exit discharge
- Stair width or stair geometry
- Handrails or guards
- Emergency lighting
- Exit signage
- Fire alarms
- Sprinklers
- Smoke or carbon monoxide detectors
- Fire-resistance ratings
- Door fire ratings
- Egress window dimensions
- Accessibility compliance
- Accessible routes
- Accessible bathrooms
- Clearance requirements
- Applicable building code
- Applicable zoning code
- Flood-zone requirements
- Wind-load requirements
- Guard or railing heights
- Structural life-safety provisions

Accordingly, no compliance determination can be made from the supplied extraction.

---

## 16. Data Gaps / Extraction Limitations

The following limitations apply to the extracted dataset.

### Identification and Sheet Data

- The project number is not provided.
- Several sheet numbers are null.
- Sheet naming is not fully consistent across the pages.
- The JSON includes both “Architecture” and “Architectural” as discipline labels.
- The specific relationship between Villa Miami and Villa Mezzo is not explicitly explained.

### Levels and Vertical Information

- Only **Villa Piano** is identified as a level.
- The connected level or levels served by the stairs are not identified.
- No floor elevations, datum references, floor-to-floor heights, or ceiling heights are provided.
- No vertical sections or elevations are included.

### Room Data

- Several spaces are listed on pages without corresponding dimensions.
- Room names and program summaries are not fully reconciled.
- The extracted program summaries indicate different bedroom and bathroom counts by page grouping, but a complete room-count reconciliation is not provided.
- Some spaces have multiple dimensional variants on the same or overlapping page groupings.
- No room areas are provided for individual spaces.
- No room finish information is provided.
- No occupancy or use classification beyond selected room functions is provided.

### Dimension Uncertainty

The following extracted values include incomplete or uncertain notation:

- Bedroom 2: **11'4" x 11'?**
- East Terrace: **9'8" x 26'?**

These values should be verified against the source drawings.

### Wall, Door, and Window Data

- Wall thicknesses and assemblies are not provided.
- Wall record associations do not include page 8.
- Door and window quantities are not provided.
- Door and window sizes, tags, schedules, hardware, and performance requirements are not provided.
- No opening dimensions or detailed terrace-edge conditions are provided.
- No columns were extracted; this is not confirmation that none are present physically.

### Systems and Fixtures

- No plumbing fixtures are enumerated.
- No kitchen or laundry equipment is enumerated.
- No mechanical, electrical, fire protection, or communications systems are identified.
- No fixture locations or equipment schedules are provided.

### Materials and Construction

- No materials or finishes were extracted.
- No construction notes, specifications, details, or installation requirements are included.
- No structural information is provided.

### References and Compliance

- No drawing references or detail callouts were extracted.
- No elevations were extracted.
- No code, accessibility, fire, egress, or life-safety information is provided.
- The dataset does not support a formal code-compliance determination.

---

## 17. Final Human-Readable Summary

The supplied document set represents the architectural floor-plan extraction for **Villa Miami / Villa Mezzo**. It contains **eight residential floor plan pages**, including Villa Mezzo plan variations on pages 1 through 6 and Villa Piano plans on pages 7 and 8.

The plans include primary bedrooms, additional bedrooms, primary bathrooms, walk-in closets, kitchens, pantries, laundry areas, foyers, living and dining spaces, family rooms, powder rooms, a WC, and east and west private terraces. The extracted program notes identify plan groupings with **3, 4, or 5 bedrooms**, corresponding bathroom quantities, one powder room, and two private terraces.

The area information identifies the following extracted ranges:

- Pages 1–2: **2,960-2,985 SF interior**, **298-350 SF exterior**, and **3,281-3,316 SF total**
- Pages 3–6: **2,936-2,972 SF interior**, **298-350 SF exterior**, and **3,267-3,302 SF total**
- Pages 7–8: **5,896-5,957 SF interior**, **596-700 SF exterior**, **185 SF foyer**, and **6,548-6,618 SF total**

The principal plan organization includes a Kitchen adjacent to the Pantry, Laundry, and living/dining areas; a Primary Bedroom adjacent to the Primary Bathroom and Walk-In Closet/WIC; living areas associated with the East Terrace and Bay view; and Family Room areas associated with the West Terrace and City view. Two interior stairs, identified as the **West Stair** and **East Stair**, provide vertical circulation to another level, with the Villa Foyer associated with the stair locations.

The extraction includes general wall categories, interior and terrace-access door categories, exterior windows and glazed openings, orientation and view annotations, and contextual references including **29TH STREET**, **BISCAYNE BAY**, and **LITTLE BLUE COVE**.

No elevations, materials, finishes, drawing references, grids, columns, equipment schedules, fixture schedules, or explicit life-safety and code-compliance data were extracted. All quantities in this report represent extracted records or stated values and should be verified against the original drawings before use for construction, pricing, permitting, coordination, or final design decisions.