# SW 1st Avenue Improvements  
## AEC Drawing Extraction Report

---

## 1. Project / Drawing Overview

### Project Information

| Item | Extracted Information |
|---|---|
| **Project name** | **SW 1st Avenue Improvements** |
| **Project number** | **B-30833** |
| **Discipline** | **Civil** |
| **Drawing type** | **Roadway plan** |
| **Drawing title** | **SW 1st AVENUE IMPROVEMENTS** |
| **Sheet number** | **8** |
| **Sheet title** | **ROADWAY PLAN** |
| **Page** | **1** |
| **Page detection status** | **ok** |

The supplied extraction contains one civil roadway plan sheet for the SW 1st Avenue Improvements project. The drawing includes roadway improvement information, milling and resurfacing limits, curb and gutter work, valley gutter references, pedestrian ramp references, existing features to remain, roadway station references, dimensions, elevations, and material legend information.

### Sheet Inventory

| Sheet | Sheet Title | Drawing Type | Discipline | Page |
|---|---|---|---|---:|
| **8** | **ROADWAY PLAN** | Roadway plan | Civil | 1 |

No additional sheets, levels, grids, or building-plan information were included in the supplied JSON.

---

## 2. Overall Element Count

The following counts represent extracted items in the supplied data. A count of zero means **0 extracted** from the provided JSON; it does not establish that the physical drawing contains no such elements.

| Element Category | Extracted Count |
|---|---:|
| Sheets | 1 |
| Levels | 0 extracted |
| Grids | 0 extracted |
| Rooms / spaces | 0 extracted |
| Walls | 0 extracted |
| Doors | 0 extracted |
| Windows | 0 extracted |
| Columns | 0 extracted |
| Stairs | 0 extracted |
| Dimensions | 7 |
| Elevations | 2 |
| Annotations / callouts | 11 |
| Drawing references | 2 |
| Materials / finish items | 4 |
| General notes | 2 |
| Spatial / roadway relationships | 4 |

The extracted information is primarily civil and roadway-related. Architectural room, wall, door, window, column, and stair data were not provided.

---

## 3. Rooms / Spaces

### Extracted Rooms and Spaces

**0 extracted.**

No rooms, enclosed spaces, building areas, or space names were identified in the supplied JSON.

### Roadway and Site Areas Referenced

Although no formal room or space objects were extracted, the drawing information references the following roadway and site-related areas:

- **SW 1st Avenue**
- **SW 15th Road**
- **SW 14th Terrace**
- **SW 14th Terrace and SW 1st Avenue intersection**
- Areas subject to **milling and resurfacing**
- Areas containing existing driveways
- Areas containing an existing fire hydrant
- Areas containing existing curb and gutter
- Areas associated with valley gutter work
- Areas associated with pedestrian ramps
- Right-of-way reference identified as **R/W LINE**

No enclosed-space areas, room dimensions, floor areas, or occupancy areas were provided.

---

## 4. Dimensions

Seven dimension or offset values were extracted from Page 1.

### Extracted Dimensions

| Value | Dimension Type | Page |
|---|---|---:|
| **50'** | Linear dimension | 1 |
| **20'** | Linear dimension | 1 |
| **30'** | Linear dimension | 1 |
| **20' R** | Radius | 1 |
| **25'** | Linear dimension | 1 |
| **5'** | Linear dimension | 1 |
| **49.00' RT** | Offset | 1 |

### Dimension Notes

- **50'**, **20'**, **30'**, **25'**, and **5'** are identified as linear dimensions.
- **20' R** is identified as a radius dimension.
- **49.00' RT** is identified as an offset. The associated annotation states:  
  **“LIMITS OF MILLING & RESURFACING 49.00' RT (MATCH EXIST.)”**
- The supplied extraction does not identify the exact geometric feature associated with each linear dimension.
- No dimensions were calculated or inferred beyond the values explicitly extracted.
- No overall roadway width, intersection width, parcel width, sidewalk width, ramp width, or pavement area was provided.

---

## 5. Wall Information

### Extracted Walls

**0 extracted.**

No building walls, retaining walls, site walls, barrier walls, or other wall elements were included in the supplied JSON.

The drawing is identified as a **civil roadway plan**, and the provided data does not include wall-specific information.

---

## 6. Doors / Windows / Openings

### Doors

**0 extracted.**

No doors or door openings were identified.

### Windows

**0 extracted.**

No windows were identified.

### Other Openings

No other building openings were explicitly extracted. The roadway plan does reference existing driveways, but the supplied data does not provide driveway dimensions, opening widths, driveway geometry, or driveway construction details.

### Existing Driveway Reference

The following annotation was extracted:

> **EXIST. DRIVEWAY (TO REMAIN)**

This indicates that an existing driveway is noted to remain. The exact location, dimensions, material, and limits of the driveway were not provided in the extracted data.

---

## 7. Equipment / Fixtures / Building Systems

### Extracted Equipment and Site Fixtures

| Item | Extracted Information | Status / Note |
|---|---|---|
| Fire hydrant | **EXIST. FIRE HYDRANT (TO REMAIN)** | Existing feature noted to remain |
| Curb and gutter | **EXIST. C&G (TO REMAIN)** | Existing feature noted to remain |
| Type F curb and gutter | **CONST. TYPE 'F' C&G (TYP.)** | Construction annotation |
| Valley gutter | **BEGIN VALLEY GUTTER** / **END VALLEY GUTTER** | Valley gutter limits referenced |
| Existing valley gutter | **REMOVE EXIST. VALLEY GUTTER** | Removal annotation |
| Pedestrian ramp | **CR-X denotes pedestrian ramp (FDOT Index 304)** | Ramp notation identified in general notes |

### Fire Protection / Utility Information

An existing fire hydrant is referenced and is noted to remain. No fire protection system design, hydrant flow information, utility size, utility alignment, water main information, or fire access criteria were provided.

### Building Systems

No mechanical, electrical, plumbing, fire alarm, fire sprinkler, structural, or building automation systems were extracted. The supplied information is limited to roadway and site-civil features.

---

## 8. Annotations / Callouts

The following annotations were extracted from Page 1.

| No. | Annotation / Callout |
|---:|---|
| 1 | **BEGIN PROJECT: BEGIN MILLING & RESURFACING STA. 10+40.00 (MATCH EXIST.)** |
| 2 | **LIMITS OF MILLING & RESURFACING 49.00' RT (MATCH EXIST.)** |
| 3 | **EXIST. DRIVEWAY (TO REMAIN)** |
| 4 | **EXIST. FIRE HYDRANT (TO REMAIN)** |
| 5 | **EXIST. C&G (TO REMAIN)** |
| 6 | **BEGIN TYPE 'F' C&G SAW CUT & MATCH EXIST.** |
| 7 | **BEGIN VALLEY GUTTER** |
| 8 | **END VALLEY GUTTER** |
| 9 | **REMOVE EXIST. VALLEY GUTTER** |
| 10 | **CONST. TYPE 'F' C&G (TYP.)** |
| 11 | **R/W LINE** |

### Interpretation of Extracted Callouts

The callouts indicate that the project includes or references:

- A project beginning at station **STA. 10+40.00**.
- Milling and resurfacing work that is to **match existing**.
- A milling and resurfacing limit identified as **49.00' RT**.
- An existing driveway, fire hydrant, and curb and gutter to remain.
- Type F curb and gutter work, including a saw-cut and match-existing condition.
- A beginning and ending point for valley gutter.
- Removal of an existing valley gutter.
- A typical construction reference for Type F curb and gutter.
- A right-of-way line.

The supplied extraction does not include graphic locations, linework geometry, or feature coordinates for these annotations.

---

## 9. Elevations

Two elevations were extracted from Page 1.

| Elevation | Location | Page |
|---|---|---:|
| **EL. 18.30** | Begin valley gutter | 1 |
| **EL. 18.39** | End valley gutter | 1 |

### Elevation Notes

- **EL. 18.30** is associated with the **begin valley gutter** location.
- **EL. 18.39** is associated with the **end valley gutter** location.
- The supplied data does not identify the vertical datum, units beyond the elevation notation, or whether the values represent existing, proposed, or finished elevations.
- No additional spot elevations, slope information, profile information, or drainage calculations were provided.

---

## 10. Materials / Finishes

Four material or finish-related entries were extracted.

| Material / Feature | Extracted Notation | Page |
|---|---|---:|
| **Sod** | Legend indicates sod | 1 |
| **4-inch concrete** | Legend indicates 4-inch concrete | 1 |
| **Detectable warning** | Legend indicates detectable warning surface | 1 |
| **Type F curb and gutter** | Existing and proposed curb and gutter annotations | 1 |

### Material Information

#### Sod

The legend indicates **sod**. No sod area, species, installation limits, or soil preparation requirements were provided.

#### 4-Inch Concrete

The legend indicates **4-inch concrete**. No concrete application area, reinforcement, jointing, strength, finish, subbase, or placement limits were provided.

#### Detectable Warning

The legend indicates a **detectable warning surface**. This material is associated in the extracted information with pedestrian ramp-related work, but the exact locations, dimensions, color, product, and installation requirements were not provided.

#### Type F Curb and Gutter

Type F curb and gutter is referenced in both existing and proposed/construction-related annotations. The extracted callouts include:

- **EXIST. C&G (TO REMAIN)**
- **BEGIN TYPE 'F' C&G SAW CUT & MATCH EXIST.**
- **CONST. TYPE 'F' C&G (TYP.)**

No curb and gutter profile dimensions, concrete specifications, reinforcement, jointing, or station limits beyond those explicitly noted were provided.

---

## 11. Construction / General Notes

### Extracted General Notes

| No. | Note |
|---:|---|
| 1 | **CR-X denotes pedestrian ramp (FDOT Index 304).** |
| 2 | **Existing driveways, fire hydrant, and curb and gutter are generally noted to remain.** |

### Construction-Related Information

The extracted annotations and notes indicate the following construction activities or conditions:

- Begin milling and resurfacing at **STA. 10+40.00**.
- Match existing conditions at the project beginning.
- Milling and resurfacing limits extend to the extracted offset of **49.00' RT**, with the annotation stating **MATCH EXIST.**
- Existing driveway is to remain.
- Existing fire hydrant is to remain.
- Existing curb and gutter is to remain where noted.
- Type F curb and gutter construction is required where shown.
- Type F curb and gutter work includes a saw-cut and match-existing condition.
- Existing valley gutter is to be removed.
- Valley gutter beginning and ending locations are identified.
- Pedestrian ramps are denoted by **CR-X**, referencing **FDOT Index 304**.

No construction sequencing, traffic control, erosion control, survey control, testing requirements, inspection requirements, contractor means and methods, or specification references were included.

---

## 12. Space Relationships

The extracted relationships describe roadway intersections, improvement limits, and pedestrian ramp locations.

| Relationship | Page |
|---|---:|
| **SW 1st Avenue intersects SW 15th Road.** | 1 |
| **SW 1st Avenue intersects SW 14th Terrace.** | 1 |
| **Milling and resurfacing limits are shown along SW 1st Avenue.** | 1 |
| **Pedestrian ramps are shown at the SW 14th Terrace and SW 1st Avenue intersection.** | 1 |

### Relationship Summary

- **SW 1st Avenue** is the primary roadway identified in the drawing title and project information.
- The plan references an intersection between **SW 1st Avenue and SW 15th Road**.
- The plan also references an intersection between **SW 1st Avenue and SW 14th Terrace**.
- Pedestrian ramps are specifically identified at the **SW 14th Terrace / SW 1st Avenue intersection**.
- Milling and resurfacing limits are shown along SW 1st Avenue.
- The extracted data does not provide intersection angles, roadway widths, lane counts, curb return geometry, sidewalk alignments, or exact feature coordinates.

---

## 13. Drawing References / Details

### Extracted Station and Match References

| Reference | Reference Type | Page |
|---|---|---:|
| **STA. 10+40.00** | Project begin station | 1 |
| **STA. 144+00.00** | Match line | 1 |

### Reference Details

#### Project Begin Station

The project begin station is identified as:

> **STA. 10+40.00**

This station is also included in the project-start annotation:

> **BEGIN PROJECT: BEGIN MILLING & RESURFACING STA. 10+40.00 (MATCH EXIST.)**

#### Match Line

A match line is identified at:

> **STA. 144+00.00**

The supplied data does not identify the adjacent sheet, continuation direction, match-line notes, or the features continued beyond this station.

#### FDOT Reference

The general note states:

> **CR-X denotes pedestrian ramp (FDOT Index 304).**

No copy of FDOT Index 304, detail dimensions, or additional standard-detail references was included in the supplied JSON.

---

## 14. Important Measurements and Areas Summary

### Extracted Measurements

| Category | Value | Description |
|---|---|---|
| Linear dimension | **50'** | Linear dimension; exact associated feature not provided |
| Linear dimension | **20'** | Linear dimension; exact associated feature not provided |
| Linear dimension | **30'** | Linear dimension; exact associated feature not provided |
| Radius | **20' R** | Radius dimension |
| Linear dimension | **25'** | Linear dimension; exact associated feature not provided |
| Linear dimension | **5'** | Linear dimension; exact associated feature not provided |
| Offset | **49.00' RT** | Milling and resurfacing offset reference |

### Extracted Elevations

| Location | Elevation |
|---|---:|
| Begin valley gutter | **EL. 18.30** |
| End valley gutter | **EL. 18.39** |

### Extracted Station References

| Reference Type | Station |
|---|---:|
| Project begin station | **STA. 10+40.00** |
| Match line | **STA. 144+00.00** |

### Areas

No areas were provided in the supplied JSON.

Specifically, the extraction does not provide:

- Project area
- Paved area
- Milling area
- Resurfacing area
- Sod area
- Concrete area
- Sidewalk area
- Ramp area
- Right-of-way area
- Drainage area
- Parcel area

No areas have been calculated from the extracted dimensions.

---

## 15. Compliance / Life Safety Information

### Extracted Accessibility Information

The drawing includes pedestrian ramp information:

- **CR-X denotes pedestrian ramp (FDOT Index 304).**
- Pedestrian ramps are shown at the **SW 14th Terrace and SW 1st Avenue intersection**.
- The legend indicates a **detectable warning surface**.

These items indicate that pedestrian accessibility-related features are represented in the roadway plan. However, the supplied data does not include ramp slopes, cross slopes, landing dimensions, detectable warning dimensions, clear widths, elevation transitions, or other compliance measurements.

### Fire and Life Safety Information

The drawing identifies:

> **EXIST. FIRE HYDRANT (TO REMAIN)**

No additional fire protection or life safety information was extracted. The supplied data does not include:

- Fire access route requirements
- Fire hydrant spacing
- Fire flow
- Fire department access
- Fire lane markings
- Emergency vehicle turning requirements
- Building occupancy information
- Egress paths
- Exit locations
- Fire alarm systems
- Fire sprinkler systems

### Regulatory and Standard References

The only explicit standard reference in the supplied JSON is:

> **FDOT Index 304**

No other code, standard, specification, permit, or agency requirement was identified.

---

## 16. Data Gaps / Extraction Limitations

The following information was not included in the supplied JSON or was not available as structured extraction.

### Drawing and Geometry Limitations

- No raster image, vector drawing, or plan graphic was supplied for visual verification.
- Exact locations of dimensions and annotations are not available.
- No linework geometry or coordinates were provided.
- The relationship between individual dimensions and specific roadway features is not identified.
- The exact limits of milling, resurfacing, curb and gutter, valley gutter removal, and pedestrian ramp work are not fully represented in the structured data.
- The direction associated with **RT** in **49.00' RT** is not further defined in the extraction.

### Site and Civil Data Not Provided

- No roadway widths
- No lane widths or lane count
- No pavement section
- No roadway grades or slopes
- No drainage structures
- No stormwater pipe or inlet information
- No utility alignments
- No survey benchmarks
- No right-of-way dimensions
- No property lines beyond the **R/W LINE** annotation
- No sidewalk dimensions
- No driveway dimensions
- No curb return dimensions
- No construction limits beyond the extracted callouts
- No quantities or bid-item information
- No station-by-station feature schedule

### Elevation and Vertical Control Limitations

- Vertical datum was not provided.
- Units or reference basis for the elevation values were not stated beyond the printed elevation notation.
- No intermediate elevations were extracted.
- No drainage slope or longitudinal grade was provided.
- No confirmation was provided as to whether the elevations are existing or proposed.

### Materials and Specifications Limitations

- No material quantities were provided.
- No product specifications were provided.
- No concrete strength was provided.
- No reinforcement information was provided.
- No detectable warning product, color, or dimensions were provided.
- No sod installation specification was provided.
- No pavement milling depth or resurfacing thickness was provided.
- No Type F curb and gutter dimensions or reinforcement details were provided.

### Architectural and Building Information Limitations

The following categories contain **0 extracted** items:

- Levels
- Grids
- Rooms
- Walls
- Doors
- Windows
- Columns
- Stairs

This should not be interpreted as confirmation that such elements are absent from the broader project documentation. The supplied JSON contains one roadway plan sheet and does not provide architectural or building-system data.

### Reference Limitations

- Only Sheet **8** was supplied.
- The match line at **STA. 144+00.00** is identified, but the continuation sheet is not provided.
- The referenced **FDOT Index 304** is not included.
- No detail callouts or cross-referenced sheets were extracted.
- No adjacent roadway plan sheets were included.

---

## 17. Final Human-Readable Summary

The supplied drawing data represents **Sheet 8, ROADWAY PLAN**, for the civil project **SW 1st Avenue Improvements**, Project No. **B-30833**. The drawing addresses roadway improvements along SW 1st Avenue, including milling and resurfacing, Type F curb and gutter work, valley gutter work, pedestrian ramps, and existing site features that are to remain.

The project begins at **STA. 10+40.00**, where milling and resurfacing are to begin and match existing conditions. The extraction also identifies a milling and resurfacing limit of **49.00' RT**, likewise noted to match existing conditions. A match line is identified at **STA. 144+00.00**.

Existing features called out to remain include an **existing driveway**, an **existing fire hydrant**, and existing **curb and gutter**. The plan also includes construction and removal references for Type F curb and gutter and valley gutters. Specifically, the extracted data identifies the beginning and end of a valley gutter, removal of an existing valley gutter, and construction of typical Type F curb and gutter.

The roadway plan references intersections of **SW 1st Avenue with SW 15th Road** and **SW 14th Terrace**. Pedestrian ramps are shown at the **SW 14th Terrace and SW 1st Avenue intersection**. The note **“CR-X denotes pedestrian ramp (FDOT Index 304)”** and the legend indication for a **detectable warning surface** provide the primary accessibility-related information in the extraction.

The drawing includes the following exact dimensional values: **50'**, **20'**, **30'**, **20' R**, **25'**, **5'**, and **49.00' RT**. Two elevations are identified at the valley gutter: **EL. 18.30** at the beginning and **EL. 18.39** at the end. The legend identifies **sod**, **4-inch concrete**, **detectable warning**, and **Type F curb and gutter**.

No rooms, walls, doors, windows, structural elements, building systems, quantities, areas, roadway widths, pavement sections, utility details, drainage design, or comprehensive construction specifications were included in the supplied extraction. All zero counts represent **0 extracted** items from the provided JSON and do not establish that those elements are physically absent from the project or from other sheets.